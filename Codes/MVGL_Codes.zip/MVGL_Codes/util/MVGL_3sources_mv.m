function [F,W,V,accuracy,obj] = MVGL_3sources_mv(X, Y, paras)

alpha = paras.alpha;
beta = paras.beta;
gamma = paras.gamma;
eta = paras.eta;
r = paras.r;
c = paras.c;
lambda = paras.lambda;
ulab_num = paras.ulab_num;
label = paras.gnd;
mask = paras.mask;
maxIter = paras.maxIter;
nv = paras.nv;
npc = paras.npc;
lab_num = paras.lab_num;

d = zeros(nv,1);
for i = 1:nv
    [d(i), n] = size(X{i});
end

innerMaxIter = maxIter;

% -------------------------------------------------------------- %
accuracy = zeros(innerMaxIter,1);
obj = zeros(maxIter,1);
% ---------------------- Initialization ------------------------ %
disp('Initialization...');
U = cell(1,nv);
for i = 1:nv
    U{i} = randn(d(i),r);
end
V = randn(r,n);
J = V;
W = randn(n,n);
F = randn(c,n);

disp('Running MVGL Algorithm...');

% -------------------- Loop --------------------- %
for loop = 1: innerMaxIter
    %%--Update Ui--%%
    for i = 1:nv
        U{i} = (X{i} * V')  / (V*V' + 2*lambda*eye(r));
    end
    
    %%--Update V--%%
    Uii = zeros(r,r);
    UiX = zeros(r,n);
    for i = 1:nv
        Uii = Uii + U{i}'*U{i};
        UiX = UiX + U{i}'*X{i};
    end
    V = (Uii + eta*(J*J') + 2*lambda*eye(r)) \ (UiX + eta*J*W);
    J = V;
    
    %%--Update S and W--%%
    WOptions.k = 15;                %--K nearest neighbors
    WOptions.WeightMode = 'Cosine'; %--Distance measurement
    WOptions.t = 1;
    S = constructW(V',WOptions);     %--Construct the graph based on low-rank codings
    S = double(full(S) > 0);
    
    W = (S.*(J'*V) + beta*(F'*F)) / (2*eta - 2*alpha);
    W = abs((W + W')/2);
    
    %%--Update F--%%
    D = zeros(n,n);
    for j = 1:n
        D(j,j) = sum(W(:,j));
    end
    F = (gamma*eye(n) + 0.5*(D-W)) \ Y';
    F = F';
    
    predicted_label = zeros(1,sum(ulab_num));
    [~,predicted_label] = max(F(:,logical(mask)));
    
    acc_t = zeros(1,c);
    for i = 1:c
        if i == 1
            true_lab = label(lab_num+1:npc(1));
            pred_label = predicted_label(1:ulab_num(1));
            tmp = nnz(true_lab==pred_label)/length(pred_label);
        else
            true_lab = label(sum(npc(1:i-1))+lab_num+1:sum(npc(1:i)));
            pred_label = predicted_label(sum(ulab_num(1:i-1))+1:sum(ulab_num(1:i)));
            tmp = nnz(true_lab==pred_label)/length(pred_label);
        end
        acc_t(i) = tmp;
    end
    
    accuracy(loop) = mean(acc_t);
    obj1 = 0;
    for i = 1:nv
        obj1 = obj1 + norm(X{i}-U{i}*V, 'fro');
    end
    obj(loop) = obj1;
end

end

