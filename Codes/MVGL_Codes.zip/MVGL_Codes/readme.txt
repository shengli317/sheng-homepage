This package includes source codes of the multi-view graph learning (MVGL) approach for semi-supervised classification. Please cite the following paper, if you find the codes are helpful.


[1] Sheng Li, Hongfu Liu, Zhiqiang Tao, and Yun Fu. "Multi-view graph learning with adaptive label propagation." IEEE International Conference on Big Data (BigData), pp. 110-115, 2017.


@inproceedings{li2017multi,
  title={Multi-view graph learning with adaptive label propagation},
  author={Li, Sheng and Liu, Hongfu and Tao, Zhiqiang and Fu, Yun},
  booktitle={IEEE International Conference on Big Data (BigData)},
  pages={110--115},
  year={2017},
  organization={IEEE}
}


The package is for academic use only. For any problem concerning the code, please feel free to contact Sheng Li (sheng.li@uga.edu).