%%%----MVGL--------%%%
%%%----Author: Sheng Li (shengli@ece.neu.edu)-------------%%%
%%%----Date: Oct. 10, 2016 (v1)--------------------------%%%
%%%----Sheng Li, Hongfu Liu, Zhiqiang Tao, and Yun Fu. "Multi-view graph learning with adaptive label propagation." 
%%%----IEEE International Conference onBig Data, pp. 110-115, 2017.

clear all;
addpath('util/');


%%%----Load the Three Sources Dataset---%%%
load('ThreeSources.mat');
load('rndidx.mat');

c = 6;
n = 169;

npc = zeros(c,1);
for i=1:c
    npc(i) = nnz(find(label==i));
end

fea1 = double(bbc);
fea2 = double(guardian);
fea3 = double(reuters);


%%%----Feature normalization---%%%
feature1 = zeros(size(fea1));
feature2 = zeros(size(fea2));
feature3 = zeros(size(fea3));
for i = 1:size(fea1,1)
    feature1(i,:) = fea1(i,:)/norm(fea1(i,:));
    feature2(i,:) = fea2(i,:)/norm(fea2(i,:));
    feature3(i,:) = fea3(i,:)/norm(fea3(i,:));
end

Acc_all = zeros(10,6);

lab_list = [1:6];

for loop = 1:10
    X = cell(3,1);
    X{1} = feature1(rndidx(:,loop),:)';
    X{2} = feature2(rndidx(:,loop),:)';
    X{3} = feature3(rndidx(:,loop),:)';
    for ratio = 1:6
        lab_num = lab_list(ratio);
        ulab_num = zeros(c,1);
        for i = 1:c
            ulab_num(i) = npc(i) - lab_num;
        end
        Y = zeros(c, n);
        mask = ones(1,n);
        for i = 1:c
            if i == 1
                Y(i, 1 : lab_num) = 1;
                mask(1 : lab_num) = 0;
            else
                Y(i, sum(npc(1:i-1))+1 : sum(npc(1:i-1))+lab_num) = 1;
                mask(sum(npc(1:i-1))+1 : sum(npc(1:i-1))+lab_num) = 0;
            end
        end
        mask = logical(mask);
        
        paras = [];
        paras.nv = 3;
        paras.alpha = 0.6;
        paras.beta = 0.05;
        paras.gamma = 0.5;
        paras.eta = 0.1;
        paras.r = 10;
        paras.lambda = 0.8;
        paras.c = c;
        paras.ulab_num = ulab_num;
        paras.mask = mask;
        paras.gnd = label;
        paras.maxIter = 30;
        paras.npc = npc;
        paras.lab_num = lab_num;
        
        [F,W,V,accuracy, obj] = MVGL_3sources_mv(X, Y, paras);
        
        disp(['Accuracy on Three Sources =' num2str(max(accuracy))]);
        Acc_all(loop,ratio) = max(accuracy);
    end
    
end
meanAcc = mean(Acc_all);
disp('Mean Accuracy (Ntr = 1 to 6):');
disp(meanAcc);


STD = std(Acc_all);
disp('STD:');
disp(STD);