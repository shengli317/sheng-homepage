This package includes source codes of our Supervised Regularization based Robust Subspace(SRRS) approach, which solves the classification problem for noisy data.

Please kindly cite the following papers.

Sheng Li, Yun Fu: Robust Subspace Discovery through Supervised Low-Rank Constraints. SDM 2014: 163-171

Sheng Li, Yun Fu: Learning Robust and Discriminative Subspace with Low-Rank Constraints. IEEE Transactions on Neural Networks and Learning Systems (T-NNLS), 27(11):2160--2173, 2016.


@inproceedings{li2014robust,
  title={Robust Subspace Discovery through Supervised Low-Rank Constraints.},
  author={Li, Sheng and Fu, Yun},
  booktitle={SDM},
  pages={163--171},
  year={2014},
  organization={SIAM}
}

@article{li2016learnrobust,
  title={Learning Robust and Discriminative Subspace with Low-Rank Constraints},
  author={Li, Sheng and Fu, Yun},
  journal={IEEE Transactions on Neural Networks and Learning Systems},
	volume={27},
	number={11},
	pages={2160--2173},
	year={2016},
  publisher={IEEE}
}


Please find detailed instructions in the "Demo_COIL_SRRS.m” script.


The package is for academic use only. For any problem concerning the code, please feel free to contact Sheng Li (shengli@ece.neu.edu).