function [ZS, ZT, D] = MMALMLRR_MSRC(XS, XT, lambda)
%%Full MM-ALM for LRSTL problem
% Input:
%   X: m x n matrix of observations/data (required input)
%   lambda: weight on sparse error term in the cost function
%   gamma1, gamma2: tuning parameters

lambda1 = lambda.lambda1;
lambda2 = lambda.lambda2;
lambda3 = lambda.lambda3;

[m, n_xs] = size(XS);
[~, n_xt] = size(XT);

X = [XS XT];
n_x = n_xs + n_xt;

XS_2Norm = norm(XS, 2);
XS_InfNorm = max(max(abs(XS)));

XT_2Norm = norm(XT, 2);
XT_InfNorm = max(max(abs(XT)));

% size of dictionary
n_d = 200;

D = rand(size(X,1), n_d);

ET = sparse(m, n_xt);
ES = sparse(m, n_xs);

gamma1 = 1;
gamma2 = 1;

tol = 1e-8;
innerMaxIter = 200;
mu = 1e-3;
mu_bar = mu * 1e7;
rho = 1.3;

disp('Initialization...');
ZT = rand(n_d,n_xt); 
ZS = rand(n_d,n_xs);
iter = 5;
J = ZT;
Y1_0 = XT / max( XT_2Norm, XT_InfNorm / lambda2 );
Y2_0 = ZT / norm(ZT);
Y3_0 = XS / max( XS_2Norm, XS_InfNorm / lambda1 );

% -------------------------- Outer Loop ------------------------ %
disp('Running MM-ALM-LRR Algorithm...');
for outiter = 1:iter
    % initial guess of weights
    sigma_J = svd(J, 'econ');
    Lambda = max(1 - sigma_J / gamma1, 0);
    W1 = max(1 - abs(ES) / gamma2, 0);
    W2 = max(1 - abs(ET) / gamma2, 0);
    Q = Y1_0;
    R = Y2_0;
    Y = Y3_0;
    dtx = D'*XT;
    inv_dtd = inv(D'*D+eye(n_d));
    % -------------------- Inner Loop --------------------- %
    for i = 1: innerMaxIter
        [J, ~] = GeneralizedSVT(ZT + R / mu, Lambda, 1 / mu);
        ZT = inv_dtd*(dtx - D'*ET + J + (D'*Q - R) / mu);
        temp = ZS + D'*(XS - D*ZS - ES + Y/mu);
        ZS = solve_l1l2(temp,lambda3/mu);
        ES = GeneralizedThresholding(XS - D*ZS + Y / mu, W1, lambda1 / mu);
        ET = GeneralizedThresholding(XT - D*ZT + Q / mu, W2, lambda2 / mu);
        leq1 = XS - D*ZS - ES;
        leq2 = XT - D*ZT - ET;
        leq3 = ZT - J;
        Y = Y + mu * leq1;
        Q = Q + mu * leq2;
        R = R + mu * leq3;
        mu = min(mu*rho, mu_bar);
        stopCriterion = max([max(max(abs(leq1))),max(max(abs(leq2))),max(max(abs(leq3)))]);
        if stopCriterion < tol
            break;
        end
    end
    
    Z = [ZS ZT];
    D = ((X-[ES ET])*Z'-Y*ZS'-Q*ZT')/((2/mu)*(Z*Z'));
    D = normcol_equal(D);
end
end


function [A_new] = GeneralizedThresholding(A, W, tau)
A_sign = sign(A);
A_new = abs(A) - tau * abs(W);
A_new(A_new < 0) = 0;
A_new = A_new .* A_sign;
end

function [X_new, sigma_new] = GeneralizedSVT(X, Lambda, tau)
[UX, SigmaX, VX] = svd(X, 'econ');
SigmaX = diag(SigmaX);
svp = length(find(SigmaX > tau));
sigma_new = GeneralizedThresholding(SigmaX(1:svp), Lambda(1:svp), tau);
X_new = UX(:, 1:svp) * diag(sigma_new) * VX(:, 1:svp)';
end

function [E] = solve_l1l2(W,lambda)
n = size(W,2);
E = W;
for i=1:n
    E(:,i) = solve_l2(W(:,i),lambda);
end
end

function [x] = solve_l2(w,lambda)
% min lambda |x|_2 + |x-w|_2^2
nw = norm(w);
if nw>lambda
    x = (nw-lambda)*w/nw;
else
    x = zeros(length(w),1);
end
end
