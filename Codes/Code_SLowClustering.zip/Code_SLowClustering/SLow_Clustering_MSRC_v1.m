%%--Self-taught low-rank coding for clustering--%%
%%--XS: source data
%%--XT: target data
%%--ZS: low-rank coding in source domain
%%--ZT: low-rank coding in target domain
%%--Z: affinity matrix

clear all;
addpath('utilities');

load('Data/LBP_LabelMe1000.mat');
XS = double(LBP);
for i = 1:size(XS,2)
    XS(:,i) = XS(:,i)./norm(XS(:,i));
end

load('Data/LBP_MSRC_v1.mat');
XT = double(LBP);
gndT = gnd';
for i = 1:length(gnd)
    XT(:,i) = XT(:,i)./norm(XT(:,i));
end
K = max(gnd);

lambda = [];
lambda.lambda1 = 0.02;
lambda.lambda2 = 0.02;
lambda.lambda3 = 1;
[ZS, ZT, Dict] = MMALMLRR_MSRC(XS,XT,lambda);

Z = ZT' * ZT;
    
%post processing
[U,S,~] = svd(Z,'econ');
S = diag(S);
r = sum(S>1e-4*S(1));
U = U(:,1:r);S = S(1:r);
U = U*diag(sqrt(S));
U = normr(U);
L = (U*U').^4;

% spectral clustering
D = diag(1./sqrt(sum(L,2)));
L = D*L*D;
[U,S,~] = svd(L);
V = U(:,1:K);
V = D*V;
    
n = size(V,1);
M = zeros(K,K,20);
rand('state',123456789);
for i=1:size(M,3)
    inds = false(n,1);
    while sum(inds)<K
        j = ceil(rand()*n);
        inds(j) = true;
    end
    M(:,:,i) = V(inds,:);
end
    
idx = kmeans(V,K,'emptyaction','singleton','start',M,'display','off');
acc =  1 - missclassGroups(idx,gndT,K)/length(idx);
disp(['seg acc=' num2str(acc)]);

