1. demo code: SLow_Clustering_MSRC_v1.m

2. main function: MMALMLRR_MSRC.m