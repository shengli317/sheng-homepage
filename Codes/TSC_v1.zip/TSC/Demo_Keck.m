% Demo of TSC (Temporal Subspace Clustering) on Keck dataset
%
% Author: Sheng Li (shengli@ece.neu.edu)
%
% Sheng Li, Kang Li, Yun Fu: Temporal Subspace Clustering for Human Motion 
% Segmentation. ICCV 2015: 4453-4461. 


clear all;
rand('state',123);

%%%---Load the data set---%%%
load('Data/P1_HIS.mat');

paths = genpath('Codes/');
addpath(paths);

%%%---Normalize the data---%%%
X = normalize(feature);

%%%---Parameter settings---%%%
paras = [];
paras.lambda1 = 0.01;
paras.lambda2 = 15;
paras.n_d = 80;
paras.ksize = 7;
paras.tol = 1e-4;
paras.maxIter = 12;
paras.stepsize = 0.1;

%%%---Learn representations Z---%%%
[D, Z, err] = TSC_ADMM(X,paras);

disp('Segmentation...');
%%%---Graph construction and segmentation---%%%
nbCluster = length(unique(label));
vecNorm = sum(Z.^2);
W2 = (Z'*Z) ./ (vecNorm'*vecNorm + 1e-6);
[oscclusters,~,~] = ncutW(W2,nbCluster);
clusters = denseSeg(oscclusters, 1);

accuracy = compacc(clusters, label);
res_nmi = nmi(label, clusters');

fprintf('Accuracy is: %f\n', accuracy);
fprintf('NMI is: %f\n', res_nmi);

plotClusters(clusters);