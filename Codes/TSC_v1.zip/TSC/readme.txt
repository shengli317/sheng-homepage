This package includes source codes of our Temporal Subspace Clustering (TSC) method, which solves the human motion segmentation problem. Please kindly cite the following paper.


Sheng Li, Kang Li, Yun Fu: Temporal Subspace Clustering for Human Motion Segmentation. ICCV 2015: 4453-4461


@inproceedings{li2015temporal,
  title={Temporal subspace clustering for human motion segmentation},
  author={Li, Sheng and Li, Kang and Fu, Yun},
  booktitle={Proceedings of the IEEE International Conference on Computer Vision},
  pages={4453--4461},
  year={2015}
}




Please find detailed instructions in the "Demo_Keck.m" script.

 
It requires the NCut package, as provided in /Codes/ncut. Please install it first.

The package is for academic use only. For any problem concerning the code, please feel free to contact Sheng Li (shengli@ece.neu.edu).