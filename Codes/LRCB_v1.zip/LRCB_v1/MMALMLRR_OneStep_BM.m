function [Z,S,iter] = MMALMLRR_OneStep_BM(X, lambda, gamma1, gamma2, lambda2, b_value)
%%Full MM-ALM b-matching for LRR problem
% Input:
%   X: m x n matrix of observations/data (required input)
%   lambda: weight on sparse error term in the cost function
%   gamma1, gamma2: tuning parameters

[m, n] = size(X);
X_2Norm = norm(X, 2);
X_InfNorm = max(max(abs(X)));

% --------------------- default parameters --------------------- %
if nargin < 2
    lambda = 1 / sqrt(m);
else
    lambda = lambda / sqrt(m);
end

if nargin < 3
    gamma1 = 4;
end

if nargin < 4
    gamma2 = 4;
end

tol = 1e-3;
innerMaxIter = 200;
mu = 1e-3;%1.5 / X_2Norm;
mu_bar = mu * 1e7;
rho = 1.2;
% -------------------------------------------------------------- %


% ---------------------- Initialization ------------------------ %
disp('Initialization via LRR...');
[J, E] = solve_lrr(X, lambda);

iter = 10;
Z = J;

xtx = X'*X;
inv_x = inv(X'*X+eye(n));

S = zeros(n,n);

% initialize Y
Y1_0 = X / max( X_2Norm, X_InfNorm / lambda );
Y2_0 = J / norm(J);
% -------------------------------------------------------------- %


% -------------------------- Outer Loop ------------------------ %
disp('Running MM-ALM-LRR Algorithm...');

% initial guess of weights
sigma_J = svd(J, 'econ');
Lambda = max(1 - sigma_J / gamma1, 0);
W = max(1 - abs(E) / gamma2, 0);
Y1 = Y1_0;
Y2 = Y2_0;

% -------------------- Inner Loop --------------------- %
for i = 1: innerMaxIter
    
    [J, sigmaJ] = GeneralizedSVT(Z + (lambda2*(S.*Z) + Y2) / mu, Lambda, 1 / mu);
    Z = inv_x*(xtx - X'*E + J + (X'*Y1 - Y2 + lambda2*(S.*J)) / mu);
    E = GeneralizedThresholding(X - X*Z + Y1 / mu, W, lambda / mu);
    
    if mod(i,10) == 0       %%--To reduce the computational cost
        %%%--Update S--%%%
        b = b_value*ones(2*n,1);
        bX = [];
        bY = [];
        weightType = 1;
        cacheSize = 0;
        mexsol = BMatchingSolver(Z'*J, b, bX, bY, weightType, cacheSize);
        mexsol = mexsol(1:n, n+1:end);
        S = logical(full(mexsol));
    end
    leq1 = X - X*Z - E;
    leq2 = Z - J;
    Y1 = Y1 + mu * leq1;
    Y2 = Y2 + mu * leq2;
    mu = min(mu*rho, mu_bar);
    
    % convergence criterion
    stopCriterion = max(max(max(abs(leq1))),max(max(abs(leq2))));
    if stopCriterion < tol
        if mod(i,10) ~= 0
            %%%--Update S--%%%
            b = b_value*ones(2*n,1);
            bX = [];
            bY = [];
            weightType = 1;
            cacheSize = 0;
            mexsol = BMatchingSolver(abs(Z')*J, b, bX, bY, weightType, cacheSize);
            mexsol = mexsol(1:n, n+1:end);
            S = logical(full(mexsol));
        end
        break;
    end
end
% ------------------------------------------------------ %

iter = iter + i;

% --------------------------------------------------------------- %

end


function [A_new] = GeneralizedThresholding(A, W, tau)
A_sign = sign(A);
A_new = abs(A) - tau * abs(W);
A_new(A_new < 0) = 0;
A_new = A_new .* A_sign;
end

function [X_new, sigma_new] = GeneralizedSVT(X, Lambda, tau)
[UX, SigmaX, VX] = svd(X, 'econ');
SigmaX = diag(SigmaX);
svp = length(find(SigmaX > tau));
sigma_new = GeneralizedThresholding(SigmaX(1:svp), Lambda(1:svp), tau);
X_new = UX(:, 1:svp) * diag(sigma_new) * VX(:, 1:svp)';
end
