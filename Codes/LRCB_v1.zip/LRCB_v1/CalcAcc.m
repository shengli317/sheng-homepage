function [accuracy] = CalcAcc(x, y)
%%--x: true label; y:clustering results

if length(x) ~= length(y)
    disp('Error!');
end

n = length(x);

costMat = zeros(n, n);

for i = 1:n
    for j = 1:n
        costMat(i,j) = abs(y(j) - x(i));
    end
end

[rowperm, colperm, ~] = KuhnMunkres(costMat);

accuracy = nnz(x(rowperm) == y(colperm)) / n;