function [rowperm, colperm, optsum] = KuhnMunkres(weights, varargin)
%KuhnMunkres    The Hungarian method
%   This function implements the Hungarian method (a.k.a. the Kuhn-Munkres
%   algorithm) that finds a solution to the assignment problem.
%   In matrix terms, it determines a permutation of a matrix with minimum
%   (or maximum) trace.
%   In graph terms, it finds a matching of a bipartite graph that minimizes
%   (or maximizes) the weights of the edges.
%
%   [ROWPERM,COLPERM] = KuhnMunkres(WEIGHTS) finds an optimal matching for
%   the matrix WEIGHTS (containing the edge weights). ROWPERM contains the
%   corresponding row permutation and COLPERM contains the corresponding
%   column permutation. The permuted matrix with optimum trace is
%   WEIGHTS(ROWPERM,COLPERM). In other words, the ROWPERM(i)-th row of the
%   matrix is matched to the COLPERM(i)-th column.
%   The matrix need not be square; in that case, some of the rows or
%   columns remain unmatched.
%
%   [ROWPERM,COLPERM,OPTSUM] = KuhnMunkres(WEIGHTS) also returns the value
%   of the trace of the optimal matrix, which equals the sum of the edge
%   weights of the optimal matching.
%
%   [ROWPERM,COLPERM,OPTSUM] = KuhnMunkres(WEIGHTS,MODE,ORDER) has two
%   optional parameters.
%   MODE selects the type of optimization
%      'min' minimizes the trace (the default option)
%      'max' maximizes the trace
%   ORDER determines the sorting order of the trace elements
%      'ascend' results in ascending order (the default option)
%      'descend' results in descending order

% (c) Dave Langers (d.r.m.langers@med.umcg.nl)

directions = {'min','max'};
direction = 1;
if (nargin > 1) && ~isequal(varargin{1}, [])
    direction = find(strcmpi(varargin{1}, directions));
end;
if isempty(direction)
    error('optimization mode must be ''min'' or ''max''.');
end;

sortorders = {'ascend','descend'};
sortorder = 1;
if (nargin > 2) && ~isequal(varargin{2}, [])
    sortorder = find(strcmpi(varargin{2}, sortorders));
end;
if isempty(sortorder)
    error('sorting order must be ''ascend'' or ''descend''.');
end;

Nrow = size(weights,1);
Ncol = size(weights,2);
if Nrow > Ncol
    [colperm, rowperm, optsum] = KuhnMunkres(weights', directions{direction}, sortorders{sortorder});
else
    colperm = zeros(Nrow,1);
    if direction == 1
        delta = weights-repmat(min(weights, [], 2), [1, Ncol]);
    else
        delta = weights-repmat(max(weights, [], 2), [1, Ncol]);
    end
    for row = 1:Nrow
        rows = false(Nrow,1);
        rows(row) = true;
        cols = false(1,Ncol);
        backtrack = zeros(Nrow,1);
        while colperm(row) == 0
            if direction == 1
                extremum = min(min(delta(rows,~cols)));
            else
                extremum = max(max(delta(rows,~cols)));
            end
            if extremum ~= 0
                delta(rows,~cols) = delta(rows,~cols)-extremum;
                delta(~rows,cols) = delta(~rows,cols)+extremum;
            end
            col = find(any(delta(rows,:) == 0, 1) & ~cols, 1);
            backtrack(col) = find((delta(:,col) == 0) & rows, 1);
            if any(colperm == col)
                cols(col) = true;
                rows(colperm == col) = true;
            else
                while col ~= 0
                    swapcol = colperm(backtrack(col));
                    colperm(backtrack(col)) = col;
                    col = swapcol;
                end
            end
        end
    end
    [optsum, rowperm] = sort(weights(sub2ind([Nrow, Ncol], (1:Nrow)', colperm)), 1, sortorders{sortorder});
    colperm = [colperm(rowperm); setdiff((1:Ncol)', colperm)];
    optsum = sum(optsum);
end