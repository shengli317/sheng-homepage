%%%----Low-Rank Coding based Graph for Clustering--------%%%
%%%----Method 2: Low-Rank Coding with b-matching sparsification-%%% 
%%%----Author: Sheng Li(shengli@ece.neu.edu)-------------%%%
%%%----Date: Aug. 20, 2013 (v2)--------------------------%%%

%%%----Usage: Please load your data in step (1)----------%%%
%%%----fea: n by d sample set. d: the dimension of data--%%%
%%%----lambda, lambda2, gamma1, gamma2: parameters used in coding-%%%

close all;

%%%----(1) Using the ORL face database as an example---%%%
load('ORL_32x32.mat');
nOfClusters = 40;
numOfSamples = size(fea,1);

%%%----(2) Feature normalization---%%%
feature = zeros(size(fea));
for i = 1:size(fea,1)
    feature(i,:) = fea(i,:)/norm(fea(i,:));
end

%%%---(3) Low-rank Coding with b-Matching Sparsification---%%%
X = feature';
lambda = 4;
lambda2 = 0.01;
gamma1 = 1;
gamma2 = 1;
b = 10;
[Z, S] = MMALMLRR_OneStep_BM(X, lambda, gamma1, gamma2, lambda2, b);
W = S.*(Z'*Z);

%%%---(4) Normalized Cut. Calculate the mean of 10 random tests---%%%  
nOfRandomTests = 10;
accuracy = zeros(1,nOfRandomTests);
for loop = 1:nOfRandomTests
    [NcutDiscrete,NcutEigenvectors,NcutEigenvalues] = ncutW(W,nOfClusters);
    
    predicted_label = zeros(numOfSamples,1);
    for i = 1:numOfSamples
        predicted_label(i) = find(NcutDiscrete(i,:) == 1);
    end
    [accuracy(loop)] = CalcAcc(gnd, predicted_label); %%%--Calculating the Clustering Accuracy
end
disp(['Clustering accuracy on ORL =' num2str(mean(accuracy))]);