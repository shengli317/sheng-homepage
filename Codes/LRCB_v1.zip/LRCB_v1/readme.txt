This package includes source codes of our Low-Rank Coding based Balanced and Unbalanced graph construction methods, which solve the clustering and semi-supervised classification problems.

Sheng Li, Yun Fu: Learning Balanced and Unbalanced Graphs via Low-Rank Coding. IEEE Trans. Knowl. Data Eng. 27(5): 1274-1287 (2015)

Sheng Li, Yun Fu: Low-Rank Coding with b-Matching Constraint for Semi-Supervised Classification. IJCAI 2013


@article{li2015learning,
  title={Learning Balanced and Unbalanced Graphs via Low-Rank Coding},
  author={Li, Sheng and Fu, Yun},
  journal={Knowledge and Data Engineering, IEEE Transactions on},
  volume={27},
  number={5},
  pages={1274--1287},
  year={2015},
  publisher={IEEE}
}

@inproceedings{li2013low,
  title={Low-rank coding with b-matching constraint for semi-supervised classification},
  author={Li, Sheng and Fu, Yun},
  booktitle={Proceedings of the Twenty-Third international joint conference on Artificial Intelligence},
  pages={1472--1478},
  year={2013},
  organization={AAAI Press}
}


This package uses the ORL face database as an example. The dataset in Matlab format is ORL_32x32.mat

Main scripts:
1. ORL_LRC_KNN_NCut.m
It performs unbalanced graph construction with K-NN constraint.

2. ORL_LRC_BM_NCut.m
It performs balanced graph construction with b-matching constraint.

Note 1: The function MMALMLRR_OneStep_BM.m used in ORL_LRC_BM_NCut.m will call the b-matching solver BMatchingSolver.mexa64. If it doesn't work in your environment, you may need to recomplie the solver using the package BMatchingSolver.zip.

Note 2: The main scripts will also call the ncutW function which can be installed using the package Ncut_9.zip.

Note 3: We only provide the application of clustering in the above two scripts. Other applications such as semi-supervised classification can be easily implemented according to our paper.

Note 4: The script ORL_LRC_KNN_NCut.m can be complied in either Windows or Linux environment. The script ORL_LRC_BM_NCut.m should be complied in Linux environment due to the requirement of b-matching solver. Usually, ORL_LRC_KNN_NCut.m is faster than ORL_LRC_BM_NCut.m, but the latter one can slightly improve the accuracy.  

Note 5: The functions "lrra.m" and "solve_lrr.m" were kindly provided by Dr. Guangcan Liu.

The package is for academic use only. For any problem concerning the code, please feel free to contact Sheng Li (shengli@ece.neu.edu).