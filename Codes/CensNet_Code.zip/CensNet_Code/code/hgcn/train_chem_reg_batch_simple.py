from __future__ import division
from __future__ import print_function

import os
import time
import argparse
import numpy as np
from tabulate import tabulate
from tqdm import tqdm
from sklearn import metrics

import torch
import torch.nn.functional as F
import torch.optim as optim

from hgcn.utils import accuracy, accuracy_mse, RMSELoss
from hgcn.utils import *
from hgcn.chem_utils import *
from hgcn.models import GCNR

# Training settings
parser = argparse.ArgumentParser()
parser.add_argument('--data_name', type=str, default='tox21',
                    help='Data name to run with')
parser.add_argument('--train_ratio', type=float, default=0.80,
                    help='The ratio of dataset for training')
parser.add_argument('--val_ratio', type=float, default=0.10,
                    help='The ratio of dataset for training')
parser.add_argument('--public_splitting', type=bool, default=False,
                    help='Use the public splitting as in Yang 2016 for citation dataset')
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--fastmode', action='store_true', default=False,
                    help='Validate during training pass.')
parser.add_argument('--seed', type=int, default=42, help='Random seed.')
parser.add_argument('--epochs', type=int, default=200,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=64,
                    help='Number of hidden units.')
parser.add_argument('--early_stopping', type=int, default=5,
                    help='Patience of early stopping')
parser.add_argument('--dropout', type=float, default=0.5,
                    help='Dropout rate (1 - keep probability).')
parser.add_argument('--replicates', type=int, default=10,
                    help='Number of experiment replicates')
parser.add_argument('--saved_name', type=str, default='sample_run.txt',
                    help='The saved file name for one run')
parser.add_argument('--graph_level', type=bool, default=True,
                    help='graph level classification flag')
parser.add_argument('--batchsize', type=int, default=512,
                     help='batchsize for minibatch training')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()

# -------------------------------------------
# Helper to run experiment
# -------------------------------------------
def experimenter(data_name='freesolv', 
                 train_ratio=0.80,
                 val_ratio=0.10,
                 cuda=True,
                 random_seed=42,
                 hidden=64,
                 dropout_ratio=0.5,
                 learning_rate=0.01,
                 weight_decay=5e-4,
                 num_epochs=100,
                 early_stopping=5,
				 batchsize = 512,
                 graph_level=True):

    print("Loading Quant Chemistry Datasets")
    data_dict, idx_train, idx_val, idx_test = load_chem(data_name = data_name, train_ratio=train_ratio, val_ratio=val_ratio)
    
    graph_size_list = []
    for i in range(len(data_dict.keys())):
        graph_size_list.append(data_dict[i][6])

    acc_val_return = []
    model = GCNR(nfeat_v=data_dict[0][2].shape[1],
                nfeat_e=data_dict[0][3].shape[1],
                nhid=hidden,
                nclass= 1,
                dropout=dropout_ratio,
                )
    print(len(data_dict.keys()))
    print(">" * 100)
    print("Loaded and preprocessed the graph data! ")
    print(">" * 100) 
    optimizer = optim.Adam(model.parameters(),
                           lr=learning_rate, 
                           weight_decay=weight_decay)
    # optimizer = optim.SGD(model.parameters(), 
    #                      lr = learning_rate, 
    #                      weight_decay=weight_decay,
    #                      momentum=0.9)
    if cuda:
        torch.cuda.manual_seed(random_seed)
        torch.set_default_tensor_type('torch.cuda.FloatTensor')
        model.cuda()
    
    criteria = F.mse_loss
    acc_measure = RMSELoss 
    # ---------------------------------------
    # training function
    # ---------------------------------------
    def train(  epoch, 
                tmatrix_batch, 
                x_batch, 
                adj_batch, 
                z_batch, 
                eadj_batch, 
                y_batch, 
                pooling,
                node_count,
                ):
        t = time.time()
        model.train()
        optimizer.zero_grad()
        output = model(x_batch,
                    z_batch,
                    eadj_batch,
                    adj_batch,
                    tmatrix_batch,
                    pooling,
                    node_count
                    )
        
        loss_train = criteria(output, y_batch)
        acc_train = acc_measure(output, y_batch)
       
        loss_train.backward()
        optimizer.step()

        '''
        if not args.fastmode:
            # Evaluate validation set performance separately,
            # deactivates dropout during validation run.
            model.eval()
            output = model(x_batch, z_batch, eadj_batch, adj_batch, tmatrix_batch, pooling, node_count)
		'''
        '''
        loss_val = criteria(output[idx_val_batch], y_batch[idx_val_batch])
		
        acc_val = acc_measure(output[idx_val_batch], y_batch[idx_val_batch])
        
		# .view(1,-1)[0]
        return loss_train.item(), acc_train.item(), loss_val.item(), acc_val.item()
        '''
        return loss_train.item(), acc_train.item()
    # -------------------------------------------
    # testing function
    # -------------------------------------------
    def eval_model(tmatrix_batch, 
             x_batch, 
             adj_batch, 
             z_batch, 
             eadj_batch, 
             y_batch, 
             pooling,
             node_count,
             ):
        model.eval()
        output = model(x_batch, 
                       z_batch, 
                       eadj_batch, 
                       adj_batch, 
                       tmatrix_batch, 
                       pooling,
                       node_count,
                       )
        loss_test = criteria(output, y_batch)
        acc_test = acc_measure(output, y_batch)
        return loss_test.item(), acc_test.item()	

	
    # Train model
    t_total = time.time()
    val_watch = []
    for epoch in range(num_epochs):
        t = time.time()
        tmp_loss_train = []
        tmp_acc_train = []
        batches = minibatchLoader([data_dict, idx_train], batchsize) 
        # to split data into batchsize, no need to record the idx_train or idx_val etc
        # batches = minibatch_chem2([data_dict, idx_train, idx_val, idx_test], batchsize)
        for batch in batches:
            adj_batch, y_batch, x_batch, eadj_batch, tmatrix_batch, z_batch, pooling_batch, node_count_batch = batch
            if cuda:
                # model.cuda()
                tmatrix_batch = tmatrix_batch.cuda()
                eadj_batch = eadj_batch.cuda()
                adj_batch = adj_batch.cuda()
                x_batch = x_batch.cuda()
                z_batch = z_batch.cuda()
                y_batch = y_batch.cuda()
                pooling_batch = pooling_batch.cuda()
                node_count_batch = node_count_batch.cuda()
                # idx_test = idx_test.cuda() 
            a,b = train(epoch, tmatrix_batch, x_batch, adj_batch, z_batch, eadj_batch, y_batch, pooling_batch, node_count_batch)
            tmp_loss_train.append(a)
            tmp_acc_train.append(b)
        
        # we do validation after each epoch
        tmp_loss_val = []
        tmp_acc_val = []
        for batch in minibatchLoader([data_dict, idx_val], batchsize):
            adj_batch, y_batch, x_batch, eadj_batch, tmatrix_batch, z_batch, pooling_batch, node_count_batch = batch
            if cuda:
                tmatrix_batch = tmatrix_batch.cuda()
                eadj_batch = eadj_batch.cuda()
                adj_batch = adj_batch.cuda()
                x_batch = x_batch.cuda()
                z_batch = z_batch.cuda()
                y_batch = y_batch.cuda()
                pooling_batch = pooling_batch.cuda()
                node_count_batch = node_count_batch.cuda()
            a, b = eval_model(tmatrix_batch, x_batch, adj_batch, z_batch, eadj_batch, y_batch, pooling_batch, node_count_batch) 
            tmp_loss_val.append(a)
            tmp_acc_val.append(b)
        acc_val_return.append(np.mean(tmp_acc_val))        
        print('Epoch: {:04d}'.format(epoch+1),
              'loss_train: {:.4f}'.format(np.mean(tmp_loss_train)),
              'RMSE_train: {:.4f}'.format(np.mean(tmp_acc_train)),
              'loss_val: {:.4f}'.format(np.mean(tmp_loss_val)),
              'RMSE_val: {:.4f}'.format(np.mean(tmp_acc_val)),
              'time: {:.4f}s'.format(time.time() - t))  
        
        val_watch.append(np.mean(tmp_loss_val))
        if epoch > early_stopping and val_watch[-1] > np.mean(val_watch[-(early_stopping + 1):-1]):
            print("Early stopping...")
            break
    print("Optimization Finished!")
    print("Total time elapsed: {:.4f}s".format(time.time() - t_total))
    print("Printing the weights : ")
   
    # save
    torch.save(acc_val_return, args.saved_name + ".pt")

    loss_test = []
    acc_test=[]
    for batch in minibatchLoader([data_dict, idx_test], batchsize):
        # tmp_loss = []
        # tmp_acc = []
        adj_batch, y_batch, x_batch, eadj_batch, tmatrix_batch, z_batch, pooling_batch, node_count_batch = batch
        if cuda:
            tmatrix_batch = tmatrix_batch.cuda()
            eadj_batch = eadj_batch.cuda()
            adj_batch = adj_batch.cuda()
            x_batch = x_batch.cuda()
            z_batch = z_batch.cuda()
            y_batch = y_batch.cuda()
            pooling_batch=pooling_batch.cuda()
            node_count_batch=node_count_batch.cuda()
             
        a, b = eval_model(tmatrix_batch, x_batch, adj_batch, z_batch, eadj_batch, y_batch, pooling_batch, node_count_batch)
        loss_test.append(a)
        acc_test.append(b)

    print("Test set results:",
          "loss= {:.4f}".format(np.mean(loss_test)),
          "RMSE= {:.4f}".format(np.mean(acc_test)))
    return np.mean(acc_test)

if __name__ == '__main__':
    # Look for your absolute directory path
    absolute_path = os.path.dirname(os.path.abspath(__file__))
    file_path = "../results/" + args.saved_name
    with open(file_path, "w") as text_file:
        for i in range(args.replicates):
            np.random.seed(args.seed)
            current_torch_seed = args.seed + int(i * 123)
            torch.manual_seed(args.seed + int(i *123))
            if args.cuda:
                torch.manual_seed(args.seed + int(i * 123))
                torch.backends.cudnn.deterministic=True
                torch.cuda.manual_seed(args.seed + int(i * 123))
            print("=" * 100)
            print("Start the ", str(i + 1), "th replicate!")
            print("=" * 100)
            print(tabulate([['task', 'quant chem classification'],
                            ['data_name', args.data_name],
                            ['current_torch_seed', current_torch_seed], 
                            ['train_ratio', args.train_ratio],
                            ['num_hidden', args.hidden],
                            ['dropout_ratio', args.dropout],
                            ['learning_rate', args.lr],
                            ['num_epochs', args.epochs],
                            ['early_stopping', args.early_stopping]
                            ], headers=['Argument', 'Value'])) 
            tmp = experimenter(
                data_name=args.data_name, 
                train_ratio=args.train_ratio,
                val_ratio=args.val_ratio,
                cuda=args.cuda,
                random_seed=args.seed,
                hidden=args.hidden,
                dropout_ratio=args.dropout,
                learning_rate=args.lr,
                weight_decay=args.weight_decay,
                num_epochs=args.epochs,
                early_stopping=args.early_stopping,
                graph_level=args.graph_level,
				batchsize=args.batchsize)
            print(tmp)
            text_file.write(str(tmp) + '\n')
            print("=" * 100)
            print("Finished the ", str(i + 1), "th replicate!")
            print("=" * 100)
