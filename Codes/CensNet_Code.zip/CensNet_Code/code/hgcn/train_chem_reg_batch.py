from __future__ import division
from __future__ import print_function

import os
import time
import argparse
import numpy as np
from tabulate import tabulate
from tqdm import tqdm
from sklearn import metrics

import torch
import torch.nn.functional as F
import torch.optim as optim

from hgcn.utils import accuracy, accuracy_mse, RMSELoss
from hgcn.utils import *
from hgcn.chem_utils import *
from hgcn.models import GCNR, EGCN

# Training settings
parser = argparse.ArgumentParser()
parser.add_argument('--data_name', type=str, default='tox21',
                    help='Data name to run with')
parser.add_argument('--train_ratio', type=float, default=0.80,
                    help='The ratio of dataset for training')
parser.add_argument('--public_splitting', type=bool, default=False,
                    help='Use the public splitting as in Yang 2016 for citation dataset')
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--fastmode', action='store_true', default=False,
                    help='Validate during training pass.')
parser.add_argument('--seed', type=int, default=42, help='Random seed.')
parser.add_argument('--epochs', type=int, default=200,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=64,
                    help='Number of hidden units.')
parser.add_argument('--early_stopping', type=int, default=5,
                    help='Patience of early stopping')
parser.add_argument('--dropout', type=float, default=0.5,
                    help='Dropout rate (1 - keep probability).')
parser.add_argument('--replicates', type=int, default=10,
                    help='Number of experiment replicates')
parser.add_argument('--saved_name', type=str, default='sample_run.txt',
                    help='The saved file name for one run')
parser.add_argument('--graph_level', type=bool, default=True,
                    help='graph level classification flag')
parser.add_argument('--batchsize', type=int, default=512,
                     help='batchsize for minibatch training')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()

# -------------------------------------------
# Helper to run experiment
# -------------------------------------------
def experimenter(data_name='freesolv', 
                 train_ratio=0.03,
                 cuda=True,
                 random_seed=42,
                 hidden=64,
                 dropout_ratio=0.5,
                 learning_rate=0.01,
                 weight_decay=5e-4,
                 num_epochs=100,
                 early_stopping=5,
				 batchsize = 512,
                 graph_level=True):

    print("Loading Quant Chemistry Datasets")
    data_dict, idx_train, idx_val, idx_test = load_chem(data_name = data_name)
    # Tmat, eadj, edge_name, adj, features, edge_features, labels, idx_train, idx_val, idx_test, pooling, node_count = tqdm(load_chem(data_name=data_name))
    # calculate the size of each graph, -> list
    graph_size_list = []
    for i in range(len(data_dict.keys())):
        graph_size_list.append(data_dict[i][6])

    # build block_diag_ones
    rows = np.repeat(list(range(len(graph_size_list))), graph_size_list) 
    cols = list(range(sum(graph_size_list)))
    values = np.ones(len(cols))
    block_diag_ones = sp.csr_matrix((values, (rows, cols)), shape=(len(graph_size_list), sum(graph_size_list))) 
    block_diag_ones = torch.FloatTensor(block_diag_ones.toarray())

    model = EGCN(nfeat_v=data_dict[0][2].shape[1],
                nfeat_e=data_dict[0][3].shape[1],
                nhid=hidden,
                nclass= 1,
                dropout=dropout_ratio,
                n_total_node = sum(graph_size_list))
    print(len(data_dict.keys()))
    print(">" * 100)
    print("Loaded and preprocessed the graph data! ")
    print(">" * 100) 
    #optimizer = optim.Adam(model.parameters(),
    #                       lr=learning_rate, 
    #                       weight_decay=weight_decay)
    optimizer = optim.SGD(model.parameters(), 
                          lr = learning_rate, 
                          weight_decay=weight_decay,
                          momentum=0.9)
    if cuda:
        torch.cuda.manual_seed(random_seed)
        torch.set_default_tensor_type('torch.cuda.FloatTensor')
        model.cuda()
    
    criteria = F.mse_loss
    acc_measure = RMSELoss 
    # ---------------------------------------
    # training function
    # ---------------------------------------
    def train(  epoch, 
                tmatrix_batch, 
                x_batch, 
                adj_batch, 
                z_batch, 
                eadj_batch, 
                y_batch, 
                idx_train_batch, 
                idx_val_batch, 
                block_diag_ones,
                batch_graph_T,
                batch_node_T):
        t = time.time()
        model.train()
        optimizer.zero_grad()
        output = model(x_batch,
                    z_batch,
                    eadj_batch,
                    adj_batch,
                    tmatrix_batch,
                    block_diag_ones,
                    batch_graph_T,
                    batch_node_T
                    )
        
        # there are many missing data on the labels, marked as -1, we should eliminate these observations when calculate the loss and auc
        # non_nan index, we only care these losses
        # train_mask = (y_batch[idx_train_batch, :] != -1)   
        # add weights
        # weights = Variable(weight_tensor(BCEweights, labels=y_batch)).view(y_batch.shape[0], y_batch.shape[1])
        # non_nan_num = Variable(torch.FloatTensor([(y_batch[idx_train_batch] == 1).sum() + (y_batch[idx_train_batch] == 0).sum()])) 
        # non_nan_num.cuda()
        # weights.cuda()

        loss_train = criteria(output[idx_train_batch], y_batch[idx_train_batch])
         
        # we use AUC as the accuracy measure
        # fpr_train, tpr_train, threshold_train \
        #                = metrics.roc_curve(y_batch[idx_train_batch][train_mask].data.cpu().numpy(), \
                                            # output[idx_train_batch][train_mask].data.cpu().numpy(), pos_label=1)
        # auc_train = metrics.auc(fpr_train, tpr_train)
        acc_train = acc_measure(output[idx_train_batch], y_batch[idx_train_batch])
       
        loss_train.backward()
        optimizer.step()

        if not args.fastmode:
            # Evaluate validation set performance separately,
            # deactivates dropout during validation run.
            model.eval()
            output = model(x_batch, z_batch, eadj_batch, adj_batch, tmatrix_batch, \
                        block_diag_ones, batch_graph_T, batch_node_T)
		
        # val_mask = (y_batch[idx_val_batch, :] != -1)
        
        # weights = Variable(weight_tensor(BCEweights, labels= y_batch)).view(y_batch.shape[0], y_batch.shape[1]) 
        # non_nan_num = Variable(torch.FloatTensor([(y_batch[idx_val_batch] == 1).sum() + (y_batch[idx_val_batch] == 0).sum()])) 
        # non_nan_num.cuda() 
        loss_val = criteria(output[idx_val_batch], y_batch[idx_val_batch])
		
        acc_val = acc_measure(output[idx_val_batch], y_batch[idx_val_batch])
        
		# .view(1,-1)[0]
        return loss_train.item(), acc_train.item(), loss_val.item(), acc_val.item()

    # -------------------------------------------
    # testing function
    # -------------------------------------------
    def test(tmatrix_batch, 
             x_batch, 
             adj_batch, 
             z_batch, 
             eadj_batch, 
             y_batch, 
             block_diag_ones,
             batch_graph_T,
             batch_node_T,
             ):
        model.eval()
        # test_mask = (y_batch != -1)
        # print("test maks is ", test_mask, test_mask.shape)
        # print("output[mask] is ", output[test_mask])
        output = model(x_batch, 
                       z_batch, 
                       eadj_batch, 
                       adj_batch, 
                       tmatrix_batch, 
                       block_diag_ones,
                       batch_graph_T,
                       batch_node_T
                       )
        # print("output[mask] is ", output[test_mask])
        # print("y batch is mask is ", y_batch[test_mask])
        loss_test = criteria(output, y_batch)
        acc_test = acc_measure(output, y_batch)
        return loss_test.item(), acc_test.item()	

	
    # Train model
    t_total = time.time()
    val_watch = []
    for epoch in range(num_epochs):
        t = time.time()
        tmp_loss_train = []
        tmp_loss_val = []
        tmp_acc_train = []
        tmp_acc_val = []

        batches = minibatch_chem([data_dict, idx_train, idx_val, idx_test], batchsize, graph_size_list)
        for batch in batches:
            adj_batch, y_batch, x_batch, eadj_batch, tmatrix_batch, z_batch, \
                        idx_train_batch, idx_val_batch, pooling_batch, node_count_batch,\
                        batch_graph_T, batch_node_T = batch
            if cuda:
                # model.cuda()
                tmatrix_batch = tmatrix_batch.cuda()
                eadj_batch = eadj_batch.cuda()
                adj_batch = adj_batch.cuda()
                x_batch = x_batch.cuda()
                z_batch = z_batch.cuda()
                y_batch = y_batch.cuda()
                idx_train_batch = idx_train_batch.cuda()
                idx_val_batch = idx_val_batch.cuda()
                pooling_batch = pooling_batch.cuda()
                node_count_batch = node_count_batch.cuda()
                batch_graph_T = batch_graph_T.cuda()
                batch_node_T = batch_node_T.cuda()
                block_diag_ones = block_diag_ones.cuda()
                # idx_test = idx_test.cuda() 
            a,b,c,d = train(epoch, tmatrix_batch, x_batch, adj_batch, z_batch, eadj_batch, y_batch, \
                            idx_train_batch, idx_val_batch, block_diag_ones, batch_graph_T, batch_node_T)
            tmp_loss_train.append(a)
            tmp_acc_train.append(b)
            tmp_loss_val.append(c)
            tmp_acc_val.append(d)

        print('Epoch: {:04d}'.format(epoch+1),
              'loss_train: {:.4f}'.format(np.mean(tmp_loss_train)),
              'auc_train: {:.4f}'.format(np.mean(tmp_acc_train)),
              'loss_val: {:.4f}'.format(np.mean(tmp_loss_val)),
              'auc_val: {:.4f}'.format(np.mean(tmp_acc_val)),
              'time: {:.4f}s'.format(time.time() - t))  
        val_watch.append(np.mean(tmp_loss_val))
        if epoch > early_stopping and val_watch[-1] > np.mean(val_watch[-(early_stopping + 1):-1]):
            print("Early stopping...")
            break
    print("Optimization Finished!")
    print("Total time elapsed: {:.4f}s".format(time.time() - t_total))
    print("Printing the weights : ")
    #for a, b in model.named_parameters():
    #      print(a, b)
    # Testing
	   # Testing
    # test_output = []
    # test_truelabel = []
    # tmp_labs = []
    # tmp_output = []
    # tmp_labs_by_group = []
    # tmp_output_by_group = []
    loss_test = []
    acc_test=[]
    for batch in minibatch_chem_test([data_dict, idx_train, idx_val, idx_test], batchsize, graph_size_list):
        # tmp_loss = []
        # tmp_acc = []
        adj_batch, y_batch, x_batch, eadj_batch, tmatrix_batch, z_batch, pooling_batch, node_count_batch, \
                                    batch_graph_T, batch_node_T = batch
        if cuda:
            tmatrix_batch = tmatrix_batch.cuda()
            eadj_batch = eadj_batch.cuda()
            adj_batch = adj_batch.cuda()
            x_batch = x_batch.cuda()
            z_batch = z_batch.cuda()
            y_batch = y_batch.cuda()
            block_diag_ones = block_diag_ones.cuda()
            batch_graph_T = batch_graph_T.cuda()
            batch_node_T = batch_node_T.cuda()
             
        a, b = test(tmatrix_batch, x_batch, adj_batch, z_batch, eadj_batch, y_batch, block_diag_ones, batch_graph_T, batch_node_T)
        loss_test.append(a)
        acc_test.append(b)

    print("Test set results:",
          "loss= {:.4f}".format(np.mean(loss_test)),
          "auc= {:.4f}".format(np.mean(acc_test)))
    return np.mean(acc_test)

if __name__ == '__main__':
    # Look for your absolute directory path
    absolute_path = os.path.dirname(os.path.abspath(__file__))
    file_path = "../results/" + args.saved_name
    with open(file_path, "w") as text_file:
        for i in range(args.replicates):
            np.random.seed(args.seed)
            current_torch_seed = args.seed + int(i * 123)
            torch.manual_seed(args.seed + int(i *123))
            if args.cuda:
                torch.manual_seed(args.seed + int(i * 123))
                torch.backends.cudnn.deterministic=True
                torch.cuda.manual_seed(args.seed + int(i * 123))
            print("=" * 100)
            print("Start the ", str(i + 1), "th replicate!")
            print("=" * 100)
            print(tabulate([['task', 'quant chem classification'],
                            ['data_name', args.data_name],
                            ['current_torch_seed', current_torch_seed], 
                            ['train_ratio', args.train_ratio],
                            ['num_hidden', args.hidden],
                            ['dropout_ratio', args.dropout],
                            ['learning_rate', args.lr],
                            ['num_epochs', args.epochs],
                            ['early_stopping', args.early_stopping]
                            ], headers=['Argument', 'Value'])) 
            tmp = experimenter(
                data_name=args.data_name, 
                train_ratio=args.train_ratio,
                cuda=args.cuda,
                random_seed=args.seed,
                hidden=args.hidden,
                dropout_ratio=args.dropout,
                learning_rate=args.lr,
                weight_decay=args.weight_decay,
                num_epochs=args.epochs,
                early_stopping=args.early_stopping,
                graph_level=args.graph_level,
				batchsize=args.batchsize)
            print(tmp)
            text_file.write(str(tmp) + '\n')
            print("=" * 100)
            print("Finished the ", str(i + 1), "th replicate!")
            print("=" * 100)
