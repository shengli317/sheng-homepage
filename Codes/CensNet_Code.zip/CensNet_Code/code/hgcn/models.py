import torch
import torch.nn as nn
import torch.nn.functional as F
from hgcn.layers import GraphConvolution, EGC, NGC, AGC, KipfGraphConvolution

class KipfGCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(KipfGCN, self).__init__()

        self.gc1 = KipfGraphConvolution(nfeat, nhid)
        self.gc2 = KipfGraphConvolution(nhid, nclass)
        self.dropout = dropout

    def forward(self, x, adj, pooling, node_count):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        # return F.log_softmax(x, dim=1)
        return torch.div(pooling @ x, node_count.view(-1, 1)) 


class GCN(nn.Module):
    def __init__(self,
        nfeat_v,
        nfeat_e,
        nhid,
        nclass,
        dropout,
        node_layer=True,
        ):
        super(GCN, self).__init__()

        self.gc1 = GraphConvolution(nfeat_v,
                                    nhid,
                                    nfeat_e,
                                    nfeat_e, # change from nhid
                                    node_layer=True)
        self.gc2 = GraphConvolution(nhid,
                                    nhid,
                                    nfeat_e,
                                    nfeat_e,
                                    node_layer=False)
        self.gc3 = GraphConvolution(nhid,
                                    nclass,
                                    nfeat_e,
                                    nfeat_e,
                                    node_layer=True)
        self.dropout = dropout
    def forward(self,
                X,
                Z,
                adj_e,
                adj_v,
                T,
                pooling=1,
                node_count=1,
                graph_level=True):
        # print x 
        gc1  = self.gc1(X, Z, adj_e, adj_v, T)
        X, Z = F.relu(gc1[0]), F.relu(gc1[1])
        
        # X, Z = F.leaky_relu(self.bn1_x(gc1[0]), negative_slope=0.05), F.leaky_relu(gc1[1], negative_slope=0.05)
        X = F.dropout(X, self.dropout, training=self.training)
        Z = F.dropout(Z, self.dropout, training=self.training)

        gc2 = self.gc2(X, Z, adj_e, adj_v, T)
        X, Z = F.relu(gc2[0]), F.relu(gc2[1])
        
        # X, Z = F.leaky_relu(gc2[0], negative_slope=0.05), F.leaky_relu(self.bn2_z(gc2[1]), negative_slope=0.05)
        X = F.dropout(X, self.dropout, training=self.training)
        Z = F.dropout(Z, self.dropout, training=self.training)

        X, Z = self.gc3(X, Z, adj_e, adj_v,T)
        # if task=="classification":
        return F.log_softmax(X, dim=1)
        # if graph_level:
        #     '''
        #     print("printing shapes")
        #     print("pooling shape is ", pooling.shape)
        #     print("X's shape is ", X.shape)
        #     print("node count shape is ", node_count.shape)
        #     print(pooling)
        #     print(X)
        #     print("the pooling @ x is ", pooling @ X)
        #     print(node_count)
        #     '''
        #     return torch.div(pooling @ X, node_count.view(-1, 1))
        # else:
        #     raise ValueError("The task is not supported!")

class EGCN(nn.Module):
    def __init__(self,
        nfeat_v,
        nfeat_e,
        nhid,
        nclass,
        dropout,
        n_total_node 
        ):
        super(EGCN, self).__init__()
        self.layer1 = NGC(nfeat_v, nhid, nfeat_e, nfeat_e)
        self.layer2 = EGC(nhid, nhid, nfeat_e, nfeat_e)
        self.layer3 = NGC(nhid, nclass, nfeat_e, nfeat_e)
        self.layer4 = AGC(n_total_node)
        self.dropout = dropout

    def forward(self,
                X,
                Z,
                adj_e,
                adj_v,
                T,
                block_diag_ones,
                batch_graph_T,
                batch_node_T
                ):
        layer1  = self.layer1(X, Z, adj_e, adj_v, T)
        X, Z = F.relu(layer1[0]), F.relu(layer1[1])
        # X, Z = F.leaky_relu(self.bn1_x(gc1[0]), negative_slope=0.05), F.leaky_relu(gc1[1], negative_slope=0.05)
        X = F.dropout(X, self.dropout, training=self.training)
        Z = F.dropout(Z, self.dropout, training=self.training)

        layer2 = self.layer2(X, Z, adj_e, adj_v, T)
        X, Z = F.relu(layer2[0]), F.relu(layer2[1])
        # X, Z = F.leaky_relu(gc2[0], negative_slope=0.05), F.leaky_relu(self.bn2_z(gc2[1]), negative_slope=0.05)
        X = F.dropout(X, self.dropout, training=self.training)
        Z = F.dropout(Z, self.dropout, training=self.training)

        X, Z = self.layer3(X, Z, adj_e, adj_v,T)
        output = self.layer4(block_diag_ones, batch_graph_T, batch_node_T, X)
        return output

class GCNR(nn.Module):
    def __init__(self,
        nfeat_v,
        nfeat_e,
        nhid,
        nclass,
        dropout,
        node_layer=True,
        ):
        super(GCNR, self).__init__()

        self.gc1 = GraphConvolution(nfeat_v,
                                    nhid,
                                    nfeat_e,
                                    nfeat_e, # change from nhid
                                    node_layer=True)
        self.gc2 = GraphConvolution(nhid,
                                    nhid,
                                    nfeat_e,
                                    nfeat_e,
                                    node_layer=False)
        self.gc3 = GraphConvolution(nhid,
                                    nclass,
                                    nfeat_e,
                                    nfeat_e,
                                    node_layer=True)
        self.dropout = dropout
        #self.bn1_x = nn.BatchNorm1d(nhid)
        #self.bn1_z = nn.BatchNorm1d(nhid)
        #self.bn2_x = nn.BatchNorm1d(nhid)
        #self.bn2_z = nn.BatchNorm1d(nhid)

    def forward(self,
                X,
                Z,
                adj_e,
                adj_v,
                T,
                pooling=1,
                node_count=1,
                graph_level=True):
        # print x 
        gc1  = self.gc1(X, Z, adj_e, adj_v, T)
        X, Z = F.relu(gc1[0]), F.relu(gc1[1])
        
        # X, Z = F.leaky_relu(self.bn1_x(gc1[0]), negative_slope=0.05), F.leaky_relu(gc1[1], negative_slope=0.05)
        X = F.dropout(X, self.dropout, training=self.training)
        Z = F.dropout(Z, self.dropout, training=self.training)

        gc2 = self.gc2(X, Z, adj_e, adj_v, T)
        X, Z = F.relu(gc2[0]), F.relu(gc2[1])
        
        # X, Z = F.leaky_relu(gc2[0], negative_slope=0.05), F.leaky_relu(self.bn2_z(gc2[1]), negative_slope=0.05)
        X = F.dropout(X, self.dropout, training=self.training)
        Z = F.dropout(Z, self.dropout, training=self.training)

        X, Z = self.gc3(X, Z, adj_e, adj_v,T)
        #if task=="classification":
        #    return F.log_softmax(X, dim=1)
        if graph_level:
            return torch.div(pooling @ X, node_count.view(-1, 1))
        else:
            raise ValueError("The task is not supported!")
