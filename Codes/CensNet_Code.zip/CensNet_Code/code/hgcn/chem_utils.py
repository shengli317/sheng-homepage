import time
import numpy as np
import scipy.sparse as sp
from scipy.sparse import csr_matrix
from scipy.linalg import block_diag
import torch
import csv
from rdkit.Chem import MolFromSmiles, SDMolSupplier
from torch.utils.data import Dataset
from neural_fp import *
import math
import os
import scipy
from sklearn.utils import shuffle, resample
import pickle
import openbabel
import pybel
import operator
from torch.autograd import Variable
import torch.nn.functional as F
from hgcn.utils import dense_tensor_to_sparse, sparse_mx_to_torch_sparse_tensor, normalize, encode_onehot 

use_cuda = torch.cuda.is_available()
FloatTensor = torch.cuda.FloatTensor if use_cuda else torch.FloatTensor
LongTensor = torch.cuda.LongTensor if use_cuda else torch.LongTensor
IntTensor = torch.cuda.IntTensor if use_cuda else torch.IntTensor
DoubleTensor = torch.cuda.DoubleTensor if use_cuda else torch.DoubleTensor

'''
def load_chem(data_name, train_ratio=0.8, test_ratio=0.1, val_ratio=0.1, path = '../data/'):
    if data_name == 'tox21':
        x_all, y_all, target, sizes = load_dc_tox21(path=path, keep_nan=True)
    elif data_name == 'hiv':
        x_all, y_all, target, sizes = load_hiv(path=path, keep_nan=True)
    elif data_name == 'lipo':
        x_all, y_all, target, sizes = load_lipo()
    elif data_name == 'freesolv':
        x_all, y_all, target, sizes = load_freesolv()
    
    path = "../data/"
	# check if the data is already prepared in the previous iteration
	precalculated_data = path + data_name + ".pt"
	print(precalculated_data)
	exist = os.path.isfile(precalculated_data)
	if exist:
		print("data already prepared, directly loaded! ")
		Tmat, EdgeAdj, EdgeName, NodeAdj, NodeFeat, EdgeFeat, labels = torch.load(precalculated_data) 
        Tmat = sparse_mx_to_torch_sparse_tensor(Tmat)
        EdgeAdj = sparse_mx_to_torch_sparse_tensor(EdgeAdj)
        NodeAdj = sparse_mx_to_torch_sparse_tensor(NodeAdj)
    else:
        # concat a block-wise adj matrix, sparse version
        allNodeAdjs = [item[1] for item in x_all]
        NodeAdj = csr_matrix(block_diag(*allNodeAdjs))
        # create a block wise node feature matrix
        # each node has 25-dimensional feature
        allNodeFeat = [item[0] for item in x_all]
        NodeFeatMat = block_diag(*allNodeFeat)
        # remove zero-valued columns, same for node features
        NodeFeatMat = NodeFeatMat[:, ~np.all(NodeFeatMat == 0, axis=0)]
        NodeFeat = csr_matrix(NodeFeatMat)

        # create edge adj and associated edge names
        EdgeAdj, EdgeName = create_edge_adj(NodeAdj) 

        # create edge features, including 5 types of features
        # type of bonds, bond order, Aromaticity, conjugation, and Ring Status
        # EdgeFeat = np.zeros((EdgeAdj.shape[0], sum([len(item) for item in x_all[0][2:7]])))
        
        bondTypeFeat = get_edge_feature_chem([item[2] for item in x_all], EdgeName)
        bondOrderFeat = get_edge_feature_chem([item[3] for item in x_all], EdgeName)
        aromFeat = get_edge_feature_chem([item[4] for item in x_all], EdgeName)
        conjFeat = get_edge_feature_chem([item[5] for item in x_all], EdgeName)
        ringStatusFeat = get_edge_feature_chem([item[6] for item in x_all], EdgeName)
        EdgeFeat = np.concatenate([bondTypeFeat, bondOrderFeat, 
                                   aromFeat, conjFeat,
                                   ringStatusFeat], axis=1)
        EdgeFeat = EdgeFeat[:, ~np.all(EdgeFeat ==0, axis=0)]
     
        # create Tmat
        Tmat = create_transition_matrix(NodeAdj)

        all_index = list(range(len(x_all)))
        np.random.shuffle(all_index)
        idx_train, idx_val, idx_test = np.split(all_index, [round(train_ratio * len(x_all)), round(train_ratio * len(x_all)) + round(len(x_all) * val_ratio)])
        # convert to torch types
        # NodeAdj = sparse_mx_to_torch_sparse_tensor(normalize(NodeAdj + sp.eye(NodeAdj.shape[0])))
        NodeFeat = torch.FloatTensor(np.array(normalize(NodeFeat).todense()))
        # EdgeAdj = sparse_mx_to_torch_sparse_tensor(normalize(EdgeAdj + sp.eye(EdgeAdj.shape[0]))) 
        EdgeFeat = normalize(EdgeFeat)
        EdgeFeat = torch.FloatTensor(EdgeFeat) 
       
        # save pre-calculated data
        print("this is the first time to preprocess the data so we save for re-use! ")
        to_save_list = [Tmat, EdgeAdj, EdgeName, NodeAdj, NodeFeat, EdgeFeat, labels]
        torch.save(to_save_list, precalculated_data)
        
        Tmat = sparse_mx_to_torch_sparse_tensor(Tmat)
        NodeAdj = sparse_mx_to_torch_sparse_tensor(normalize(NodeAdj + sp.eye(NodeAdj.shape[0])))
        EdgeAdj = sparse_mx_to_torch_sparse_tensor(normalize(EdgeAdj + sp.eye(EdgeAdj.shape[0])))
    # create block wise response! very important!
    y = np.array(y_all).reshape((1, len(y_all)))[0]
    NumofNodes = [item[1].shape[0] for item in x_all]
    # Y = np.repeat(y, NumofNodes)
    # labels = torch.FloatTensor(Y.reshape((len(Y),1)))
    labels = torch.FloatTensor(y) 
    # convert train, val, and test ids to node level
    ind = list(range(len(x_all)))
    repeated_ind = np.repeat(ind, NumofNodes)
    
    # idx_train = np.in1d(repeated_ind, idx_train).nonzero()[0]
    # idx_val = np.in1d(repeated_ind, idx_val).nonzero()[0]
    # idx_test = np.in1d(repeated_ind, idx_test).nonzero()[0]
    
    # print(len(idx_train), len(idx_val), len(idx_test))

    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)
    
    # we need a feature map in the last step, acting as a pooling
    pooling = torch.FloatTensor(encode_onehot(repeated_ind).T)
    NodeCount = torch.FloatTensor(np.array(NumofNodes).reshape((len(NumofNodes),1)))
    # NodeCount = torch.FloatTensor(NumofNodes)
    return Tmat, EdgeAdj, EdgeName, NodeAdj, NodeFeat, EdgeFeat, labels, idx_train, idx_val, idx_test, pooling, NodeCount      
'''

def load_chem(data_name, train_ratio=0.8, test_ratio=0.1, val_ratio=0.1, path = '../data/'):
    to_save_data = "../data/" + data_name + ".pt"
    exist = os.path.isfile(to_save_data)
    if exist:
        print("Data already preprocessed so we just load it...")
        RES = torch.load(to_save_data)
    else:
        print("First time to preprocess data, we will save it for re-use...")
        if data_name == 'tox21':
            x_all, y_all, target, sizes = load_dc_tox21(path=path, keep_nan=True)
        elif data_name == 'hiv':
            x_all, y_all, target, sizes = load_hiv(path=path, keep_nan=True)
        elif data_name == 'lipo':
            x_all, y_all, target, sizes = load_lipo()
        elif data_name == 'freesolv':
            x_all, y_all, target, sizes = load_freesolv()
        RES = prepare_data_dict([x_all, y_all, target, sizes]) 
        torch.save(RES, to_save_data)
    # sampling training, val and test
    N = len(RES.keys())
    ids = np.array(range(N))
    ys = []
    for i in range(N):
        ys.append(RES[i][4])
    ys = np.concatenate(ys)
    if data_name == 'hiv':
        pos_id = np.where(ys == 1)[0]
        neg_id = np.where(ys == 0)[0]
        print(pos_id)
        print(np.random.choice(neg_id, 5000, replace=False))
        ids = np.concatenate([np.random.choice(neg_id, 5000, replace=False), pos_id])
        # ids = np.random.choice(ids, N // 6 , replace=False)
        N = len(ids)
    np.random.shuffle(ids)
    idx_train = ids[0: round(train_ratio * N)]
    idx_val = ids[round(train_ratio * N): round((train_ratio + val_ratio)*N)]
    idx_test = ids[round((train_ratio + val_ratio)*N):]

    return RES, idx_train, idx_val, idx_test

# helper function to get edge features
def get_edge_feature_chem(one_type_feature_list, EdgeName):
    # [tensor, ..., tensor], with length = num of graphs
    feature_df = np.zeros((len(EdgeName), len(one_type_feature_list[0])))
    all_this_feat = []
    for j in range(len(one_type_feature_list[0])):
        tmp1 = [cube[j, :, :] for cube in one_type_feature_list]
        all_this_feat.append(block_diag(*tmp1))
    all_this_feat_tensor = np.stack(all_this_feat)
    num_feat = len(one_type_feature_list[0])
    for i in range(len(EdgeName)):
        index1, index2 = EdgeName[i]
        feature_df[i, :] = all_this_feat_tensor[:, index1, index2]
    return feature_df

def node_adj_to_edge_adj(vertex_adj):
    ''' 
    create an edge adjacency matrix from vertex adjacency matrix
    '''
    np.fill_diagonal(vertex_adj, 0)
    edge_index = np.nonzero(np.triu(vertex_adj))
    num_edge = int(len(edge_index[0]))
    edge_name = [x for x in zip(edge_index[0], edge_index[1])]

    edge_adj = np.zeros((num_edge, num_edge))
    for i in range(num_edge):
        for j in range(i, num_edge):
            if len(set(edge_name[i]) & set(edge_name[j])) == 0:
                edge_adj[i, j] = 0 
            else:
                edge_adj[i, j] = 1 
    adj = edge_adj + edge_adj.T
    np.fill_diagonal(adj, 1)
    return adj, edge_name

def get_transition_matrix(vertex_adj):
    '''create N_v * N_e transition matrix'''
    np.fill_diagonal(vertex_adj, 0)
    edge_index = np.nonzero(np.triu(vertex_adj))
    num_edge = int(len(edge_index[0]))
    edge_name = [x for x in zip(edge_index[0], edge_index[1])]

    row_index = [i for sub in edge_name for i in sub]
    col_index = np.repeat([i for i in range(num_edge)], 2)

    data = np.ones(num_edge * 2)
    T = sp.csr_matrix((data, (row_index, col_index)),
               shape=(vertex_adj.shape[0], num_edge))

    return T.toarray()

def connection_type_to_edge_feat(connection_type, edge_name):
    n_feat = connection_type.shape[0]
    feat_df = np.zeros((len(edge_name), n_feat))

    edge_id_name_dict = {k: v for v, k in enumerate(edge_name)}
    ids = np.where(np.triu(connection_type, 1) != 0)
    row_idx = list(map(edge_id_name_dict.get, zip(ids[1], ids[2])))
    col_idx = ids[0]
    # print(row_idx, col_idx)
    feat_df[row_idx, col_idx] = 1
    return feat_df
    
def load_lipo(path='../data/', dataset = 'Lipophilicity.csv', bondtype_freq = 10,
                    atomtype_freq=10):
    print('Loading {} dataset...'.format(dataset))
    data = []
    with open('{}{}'.format(path, dataset), 'r') as data_fid:
        reader = csv.reader(data_fid, delimiter=',', quotechar='"')
        for row in reader:
            data.append(row)
    print('done')

    target = data[0][1]
    labels = []
    mol_sizes = []
    error_row = []
    bondtype_dic, atomtype_dic = got_all_Type_solu_dic(dataset)

    sorted_bondtype_dic = sorted(bondtype_dic.items(), key=operator.itemgetter(1))
    sorted_bondtype_dic.reverse()
    bondtype_list_order = [ele[0] for ele in sorted_bondtype_dic]
    bondtype_list_number = [ele[1] for ele in sorted_bondtype_dic]

    filted_bondtype_list_order = []
    for i in range(0, len(bondtype_list_order)):
        if bondtype_list_number[i] > bondtype_freq:
            filted_bondtype_list_order.append(bondtype_list_order[i])
    filted_bondtype_list_order.append('Others')

    sorted_atom_types_dic = sorted(atomtype_dic.items(), key=operator.itemgetter(1))
    sorted_atom_types_dic.reverse()
    atomtype_list_order = [ele[0] for ele in sorted_atom_types_dic]
    atomtype_list_number = [ele[1] for ele in sorted_atom_types_dic]

    filted_atomtype_list_order = []
    for i in range(0, len(atomtype_list_order)):
        if atomtype_list_number[i] > atomtype_freq:
            filted_atomtype_list_order.append(atomtype_list_order[i])
    filted_atomtype_list_order.append('Others')

    print('filted_atomtype_list_order: {}, \n filted_bondtype_list_order: {}'.format(filted_atomtype_list_order, filted_bondtype_list_order))

    x_all = []
    count_1 = 0
    count_2 = 0
    for i in range(1, len(data)):
        mol = MolFromSmiles(data[i][2])
        count_1 += 1
        try:
            (afm, adj, bft, adjTensor_OrderAtt,
             adjTensor_AromAtt, adjTensor_ConjAtt, adjTensor_RingAtt) = molToGraph(mol, filted_bondtype_list_order,
                                                                                   filted_atomtype_list_order).dump_as_matrices_Att()
            mol_sizes.append(adj.shape[0])
            labels.append([np.float32(data[i][1])])
            x_all.append([afm, adj, bft, adjTensor_OrderAtt, adjTensor_AromAtt, adjTensor_ConjAtt, adjTensor_RingAtt])
            count_2 += 1
        except AttributeError:
            print('the {}th row has an error'.format(i))
            error_row.append(i)
        except TypeError:
            print('the {}th row smile is: {}, can not convert to graph structure'.format(i, data[i][2]))
            error_row.append(i)
        else:
            pass
        i += 1

    x_all = feature_normalize(x_all)
    print('Done.')

    return(x_all, labels, target, mol_sizes)

def load_freesolv(path='../data/', dataset = 'SAMPL.csv', bondtype_freq = 3,
                    atomtype_freq=3):
    print('Loading {} dataset...'.format(dataset))
    data = []
    with open('{}{}'.format(path, dataset), 'r') as data_fid:
        reader = csv.reader(data_fid, delimiter=',', quotechar='"')
        for row in reader:
            data.append(row)
    print('done')

    target = data[0][2]
    labels = []
    mol_sizes = []
    error_row = []
    bondtype_dic, atomtype_dic = got_all_Type_solu_dic(dataset)

    sorted_bondtype_dic = sorted(bondtype_dic.items(), key=operator.itemgetter(1))
    sorted_bondtype_dic.reverse()
    bondtype_list_order = [ele[0] for ele in sorted_bondtype_dic]
    bondtype_list_number = [ele[1] for ele in sorted_bondtype_dic]

    filted_bondtype_list_order = []
    for i in range(0, len(bondtype_list_order)):
        if bondtype_list_number[i] > bondtype_freq:
            filted_bondtype_list_order.append(bondtype_list_order[i])
    filted_bondtype_list_order.append('Others')

    sorted_atom_types_dic = sorted(atomtype_dic.items(), key=operator.itemgetter(1))
    sorted_atom_types_dic.reverse()
    atomtype_list_order = [ele[0] for ele in sorted_atom_types_dic]
    atomtype_list_number = [ele[1] for ele in sorted_atom_types_dic]

    filted_atomtype_list_order = []
    for i in range(0, len(atomtype_list_order)):
        if atomtype_list_number[i] > atomtype_freq:
            filted_atomtype_list_order.append(atomtype_list_order[i])
    filted_atomtype_list_order.append('Others')

    print('filted_atomtype_list_order: {}, \n filted_bondtype_list_order: {}'.format(filted_atomtype_list_order, filted_bondtype_list_order))

    x_all = []
    count_1 = 0
    count_2 = 0
    for i in range(1, len(data)):
        mol = MolFromSmiles(data[i][1])
        count_1 += 1
        try:
            (afm, adj, bft, adjTensor_OrderAtt,
             adjTensor_AromAtt, adjTensor_ConjAtt, adjTensor_RingAtt) = molToGraph(mol, filted_bondtype_list_order,
                                         filted_atomtype_list_order).dump_as_matrices_Att()
            mol_sizes.append(adj.shape[0])
            labels.append([np.float32(data[i][2])])
            x_all.append([afm, adj, bft, adjTensor_OrderAtt, adjTensor_AromAtt, adjTensor_ConjAtt, adjTensor_RingAtt])
            count_2 +=1
        except AttributeError:
            print('the {}th row has an error'.format(i))
            error_row.append(i)
        except TypeError:
            print('the {}th row smile is: {}, can not convert to graph structure'.format(i, data[i][1]))
            error_row.append(i)
        i += 1

    x_all = feature_normalize(x_all)
    print('Done.')

    return(x_all, labels, target, mol_sizes)

def load_dc_tox21(path='../data/', dataset = 'tox21.csv', bondtype_freq =20, atomtype_freq =10, keep_nan=True):
    print('Loading {} dataset...'.format(dataset))
    data = []
    with open('{}{}'.format(path, dataset), 'r') as data_fid:
        reader = csv.reader(data_fid, delimiter=',', quotechar='"')
        for row in reader:
            data.append(row)

    label_name = data[0][0:12]
    target = label_name

    bondtype_dic, atomtype_dic = got_all_Type_solu_dic(dataset)

    sorted_bondtype_dic = sorted(bondtype_dic.items(), key=operator.itemgetter(1))
    sorted_bondtype_dic.reverse()
    bondtype_list_order = [ele[0] for ele in sorted_bondtype_dic]
    bondtype_list_number = [ele[1] for ele in sorted_bondtype_dic]

    filted_bondtype_list_order = []
    for i in range(0, len(bondtype_list_order)):
        if bondtype_list_number[i] > bondtype_freq:
            filted_bondtype_list_order.append(bondtype_list_order[i])
    filted_bondtype_list_order.append('Others')

    sorted_atom_types_dic = sorted(atomtype_dic.items(), key=operator.itemgetter(1))
    sorted_atom_types_dic.reverse()
    atomtype_list_order = [ele[0] for ele in sorted_atom_types_dic]
    atomtype_list_number = [ele[1] for ele in sorted_atom_types_dic]

    filted_atomtype_list_order = []
    for i in range(0, len(atomtype_list_order)):
        if atomtype_list_number[i] > atomtype_freq:
            filted_atomtype_list_order.append(atomtype_list_order[i])
    filted_atomtype_list_order.append('Others')

    print('filted_atomtype_list_order: {}, \n filted_bondtype_list_order: {}'.format(filted_atomtype_list_order,
                                                                                     filted_bondtype_list_order))

    # mol to graph
    i = 0
    mol_sizes = []
    x_all = []
    y_all = []
    print('Transfer mol to matrices')
    for row in data[1:]:
        smile = row[13]
        mol = MolFromSmiles(smile)

        label = row[0:12]
        label = ['nan' if ele=='' else ele for ele in label]
        num_label = [float(x) for x in label]
        num_label = [-1 if math.isnan(x) else x for x in num_label]

        idx = i+1
        i = i + 1
        try:
            (afm, adj, bft, adjTensor_OrderAtt,
             adjTensor_AromAtt, adjTensor_ConjAtt, adjTensor_RingAtt) = molToGraph(mol, filted_bondtype_list_order,
                                                                                   filted_atomtype_list_order).dump_as_matrices_Att()
            x_all.append([afm, adj, bft, adjTensor_OrderAtt, adjTensor_AromAtt, adjTensor_ConjAtt, adjTensor_RingAtt])
            y_all.append(num_label)
            mol_sizes.append(adj.shape[0])
            # feature matrices of mols, include Adj Matrix, Atom Feature, Bond Feature.
        except AttributeError:
            print('the {}th row has an error'.format(i))
        except TypeError:
            print('the {}th row smile is: {}, can not convert to graph structure'.format(i, smile))
        else:
            pass
    x_all = feature_normalize(x_all)
    print('Done.')
    return (x_all, y_all, target, mol_sizes)

def load_hiv(path='../data/', dataset = 'HIV.csv', bondtype_freq =20, atomtype_freq =10, keep_nan=True):
    print('Loading {} dataset...'.format(dataset))
    data = []
    with open('{}{}'.format(path, dataset), 'r') as data_fid:
        reader = csv.reader(data_fid, delimiter=',', quotechar='"')
        for row in reader:
            data.append(row)

    label_name = data[0][2]
    target = [label_name]

    bondtype_dic, atomtype_dic = got_all_Type_solu_dic(dataset)

    sorted_bondtype_dic = sorted(bondtype_dic.items(), key=operator.itemgetter(1))
    sorted_bondtype_dic.reverse()
    bondtype_list_order = [ele[0] for ele in sorted_bondtype_dic]
    bondtype_list_number = [ele[1] for ele in sorted_bondtype_dic]

    filted_bondtype_list_order = []
    for i in range(0, len(bondtype_list_order)):
        if bondtype_list_number[i] > bondtype_freq:
            filted_bondtype_list_order.append(bondtype_list_order[i])
    filted_bondtype_list_order.append('Others')

    sorted_atom_types_dic = sorted(atomtype_dic.items(), key=operator.itemgetter(1))
    sorted_atom_types_dic.reverse()
    atomtype_list_order = [ele[0] for ele in sorted_atom_types_dic]
    atomtype_list_number = [ele[1] for ele in sorted_atom_types_dic]

    filted_atomtype_list_order = []
    for i in range(0, len(atomtype_list_order)):
        if atomtype_list_number[i] > atomtype_freq:
            filted_atomtype_list_order.append(atomtype_list_order[i])
    filted_atomtype_list_order.append('Others')

    print('filted_atomtype_list_order: {}, \n filted_bondtype_list_order: {}'.format(filted_atomtype_list_order, filted_bondtype_list_order))

    # mol to graph
    i = 0
    mol_sizes = []
    x_all = []
    y_all = []
    print('Transfer mol to matrices')
    for row in data[1:]:
        i+=1
        if len(row) ==0:
            continue
        smile = row[0]
        label = row[2]
        label = [label]
        label = ['nan' if ele=='' else ele for ele in label]
        num_label = [float(x) for x in label]
        num_label = [-1 if math.isnan(x) else x for x in num_label]
        try:
            mol = MolFromSmiles(smile)
            (afm, adj, bft, adjTensor_OrderAtt,
             adjTensor_AromAtt, adjTensor_ConjAtt, adjTensor_RingAtt) = molToGraph(mol, filted_bondtype_list_order,
                                                                                   filted_atomtype_list_order).dump_as_matrices_Att()
            x_all.append([afm, adj, bft, adjTensor_OrderAtt, adjTensor_AromAtt, adjTensor_ConjAtt, adjTensor_RingAtt])
            y_all.append(num_label)
            mol_sizes.append(adj.shape[0])
            # feature matrices of mols, include Adj Matrix, Atom Feature, Bond Feature.
        except AttributeError:
            print('the {}th row has an error'.format(i))
        except ValueError:
            print('the {}th row smile is: {}, can not convert to graph structure'.format(i, smile))
        else:
            pass
    x_all = feature_normalize(x_all)
    print('Done.')
    return (x_all, y_all, target, mol_sizes)

def data_filter(x_all, y_all, target, sizes, tasks, size_cutoff=1000):
    idx_row = []
    for i in range(0, len(sizes)):
        if sizes[i] <= size_cutoff:
            idx_row.append(i)
    x_select = [x_all[i] for i in idx_row]
    y_select = [y_all[i] for i in idx_row]

    idx_col = []
    for task in tasks:
        for i in range(0, len(target)):
            if task == target[i]:
                idx_col.append(i)
    y_task = [[each_list[i] for i in idx_col] for each_list in y_select]

    return(x_select, y_task)

def normalize(mx):
    """Row-normalize sparse matrix"""
    mx_abs = np.absolute(mx)
    #rowsum = np.array(mx.sum(1))
    rowsum = np.array(mx_abs.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx

def feature_normalize(x_all):
    """Min Max Feature Scalling for Atom Feature Matrix"""
    feature_num = x_all[0][0].shape[1]
    feature_min_dic = {}
    feature_max_dic = {}
    for i in range(len(x_all)):
        afm = x_all[i][0]
        afm_min = afm.min(0)
        afm_max = afm.max(0)
        for j in range(feature_num):
            if j not in feature_max_dic.keys():
                feature_max_dic[j] = afm_max[j]
                feature_min_dic[j] = afm_min[j]
            else:
                if feature_max_dic[j] < afm_max[j]:
                    feature_max_dic[j] = afm_max[j]
                if feature_min_dic[j] > afm_min[j]:
                    feature_min_dic[j] = afm_min[j]

    for i in range(len(x_all)):
        afm = x_all[i][0]
        feature_diff_dic = {}
        for j in range(feature_num):
            feature_diff_dic[j] = feature_max_dic[j]-feature_min_dic[j]
            if feature_diff_dic[j] ==0:
                feature_diff_dic[j] = 1
            afm[:,j] = (afm[:,j] - feature_min_dic[j])/(feature_diff_dic[j])
        x_all[i][0] = afm
    return x_all

class MolDatum():
    """
        Class that represents a train/validation/test datum
        - self.label: 0 neg, 1 pos -1 missing for different target.
    """
    def __init__(self, x, label, target, index):
        self.adj = x[1]
        self.afm = x[0]
        self.bft = x[2]
        self.orderAtt = x[3]
        self.aromAtt = x[4]
        self.conjAtt = x[5]
        self.ringAtt = x[6]
        self.label = label
        self.target = target
        self.index = index

def construct_dataset(x_all, y_all, target):
    output = []
    for i in range(len(x_all)):
        output.append(MolDatum(x_all[i], y_all[i], target, i))
    return(output)

class MolDataset(Dataset):
    """
    Class that represents a train/validation/test dataset that's readable for PyTorch
    Note that this class inherits torch.utils.data.Dataset
    """

    def __init__(self, data_list):
        """
        @param data_list: list of MolDatum
        """
        self.data_list = data_list

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, key):
        """
        Triggered when you call dataset[i]
        """
        adj, afm, bft, orderAtt, aromAtt, conjAtt, ringAtt  = self.data_list[key].adj, self.data_list[key].afm, self.data_list[key].bft, \
                                                              self.data_list[key].orderAtt, self.data_list[key].aromAtt, self.data_list[key].conjAtt, self.data_list[key].ringAtt
        label = self.data_list[key].label
        return (adj, afm, bft, orderAtt, aromAtt, conjAtt, ringAtt, label)

def mol_collate_func_reg(batch):
    """
    Customized function for DataLoader that dynamically pads the batch so that all
    data have the same length
    """
    adj_list = []
    afm_list =[]
    label_list = []
    size_list = []
    bft_list = []
    orderAtt_list, aromAtt_list, conjAtt_list, ringAtt_list = [], [], [], []
    for datum in batch:
        label_list.append(datum[7])
        size_list.append(datum[0].shape[0])
    max_size = np.max(size_list) # max of batch. 55 for solu, 115 for lipo, 24 for freesolv
    #max_size = max_molsize #max_molsize 132
    btf_len = datum[2].shape[0]
    # padding
    for datum in batch:
        filled_adj = np.zeros((max_size, max_size), dtype=np.float32)
        filled_adj[0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[0]
        filled_afm = np.zeros((max_size, 25), dtype=np.float32)
        filled_afm[0:datum[0].shape[0], :] = datum[1]
        filled_bft = np.zeros((btf_len, max_size, max_size), dtype=np.float32)
        filled_bft[:, 0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[2]

        filled_orderAtt = np.zeros((5, max_size, max_size), dtype=np.float32)
        filled_orderAtt[:, 0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[3]

        filled_aromAtt = np.zeros((3, max_size, max_size), dtype=np.float32)
        filled_aromAtt[:, 0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[4]

        filled_conjAtt = np.zeros((3, max_size, max_size), dtype=np.float32)
        filled_conjAtt[:, 0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[5]

        filled_ringAtt = np.zeros((3, max_size, max_size), dtype=np.float32)
        filled_ringAtt[:, 0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[6]

        adj_list.append(filled_adj)
        afm_list.append(filled_afm)
        bft_list.append(filled_bft)
        orderAtt_list.append(filled_orderAtt)
        aromAtt_list.append(filled_aromAtt)
        conjAtt_list.append(filled_conjAtt)
        ringAtt_list.append(filled_ringAtt)


    if use_cuda:
        return ([torch.from_numpy(np.array(adj_list)).cuda(), torch.from_numpy(np.array(afm_list)).cuda(),
                 torch.from_numpy(np.array(bft_list)).cuda(), torch.from_numpy(np.array(orderAtt_list)).cuda(),
                 torch.from_numpy(np.array(aromAtt_list)).cuda(), torch.from_numpy(np.array(conjAtt_list)).cuda(),
                 torch.from_numpy(np.array(ringAtt_list)).cuda(),
                 torch.from_numpy(np.array(label_list)).cuda()])
    else:
        return ([torch.from_numpy(np.array(adj_list)), torch.from_numpy(np.array(afm_list)),
                 torch.from_numpy(np.array(bft_list)), torch.from_numpy(np.array(orderAtt_list)),
                 torch.from_numpy(np.array(aromAtt_list)), torch.from_numpy(np.array(conjAtt_list)),
                 torch.from_numpy(np.array(ringAtt_list)),
                 torch.from_numpy(np.array(label_list))])

def mol_collate_func_class(batch):

    adj_list = []
    afm_list =[]
    label_list = []
    size_list = []
    bft_list = []
    orderAtt_list, aromAtt_list, conjAtt_list, ringAtt_list = [], [], [], []

    for datum in batch:
        label_list.append(datum[7])
        size_list.append(datum[0].shape[0])
    max_size = np.max(size_list) # max of batch    222 for hiv, 132 for tox21,
    btf_len = datum[2].shape[0]
    #max_size = max_molsize #max_molsize 132
    # padding
    for datum in batch:
        filled_adj = np.zeros((max_size, max_size), dtype=np.float32)
        filled_adj[0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[0]
        filled_afm = np.zeros((max_size, 25), dtype=np.float32)
        filled_afm[0:datum[0].shape[0], :] = datum[1]
        filled_bft = np.zeros((btf_len, max_size, max_size), dtype=np.float32)
        filled_bft[:, 0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[2]

        filled_orderAtt = np.zeros((5, max_size, max_size), dtype=np.float32)
        filled_orderAtt[:, 0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[3]

        filled_aromAtt = np.zeros((3, max_size, max_size), dtype=np.float32)
        filled_aromAtt[:, 0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[4]

        filled_conjAtt = np.zeros((3, max_size, max_size), dtype=np.float32)
        filled_conjAtt[:, 0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[5]

        filled_ringAtt = np.zeros((3, max_size, max_size), dtype=np.float32)
        filled_ringAtt[:, 0:datum[0].shape[0], 0:datum[0].shape[0]] = datum[6]

        adj_list.append(filled_adj)
        afm_list.append(filled_afm)
        bft_list.append(filled_bft)
        orderAtt_list.append(filled_orderAtt)
        aromAtt_list.append(filled_aromAtt)
        conjAtt_list.append(filled_conjAtt)
        ringAtt_list.append(filled_ringAtt)

    if use_cuda:
        return ([torch.from_numpy(np.array(adj_list)).cuda(), torch.from_numpy(np.array(afm_list)).cuda(),
                 torch.from_numpy(np.array(bft_list)).cuda(), torch.from_numpy(np.array(orderAtt_list)).cuda(),
                 torch.from_numpy(np.array(aromAtt_list)).cuda(), torch.from_numpy(np.array(conjAtt_list)).cuda(),
                 torch.from_numpy(np.array(ringAtt_list)).cuda(),
                 FloatTensor(label_list)])
    else:
        return ([torch.from_numpy(np.array(adj_list)), torch.from_numpy(np.array(afm_list)),
             torch.from_numpy(np.array(bft_list)),torch.from_numpy(np.array(orderAtt_list)),
                 torch.from_numpy(np.array(aromAtt_list)), torch.from_numpy(np.array(conjAtt_list)),
                 torch.from_numpy(np.array(ringAtt_list)),
                 FloatTensor(label_list)])

def weighted_binary_cross_entropy(output, target, weights=None):
    if weights is not None:
        assert len(weights) == 2

        loss = weights[1] * (target * torch.log(output)) + \
               weights[0] * ((1 - target) * torch.log(1 - output))
    else:
        loss = target * torch.log(output) + (1 - target) * torch.log(1 - output)

    return torch.neg(torch.mean(loss))

def weight_tensor(weights, labels):
    # when labels is variable
    weight_tensor = []
    a = IntTensor([1])
    b = IntTensor([0])
    for i in range(0, labels.data.shape[0]):
        for j in range(0, labels.data.shape[1]):
            if torch.equal(IntTensor([int(labels.data[i][j])]), a):
                weight_tensor.append(weights[j][0])
            elif torch.equal(IntTensor([int(labels.data[i][j])]), b):
                weight_tensor.append(weights[j][1])
            else:
                weight_tensor.append(0)
    if use_cuda:
        return (torch.from_numpy(np.array(weight_tensor, dtype=np.float32)).cuda())
    else:
        return(torch.from_numpy(np.array(weight_tensor, dtype=np.float32)))

def set_weight(y_all):
    weight_dic = {}
    pos_dic ={}
    neg_dic = {}
    for i in range(len(y_all)):
        for j in range(len(y_all[0])):
            if y_all[i][j] == 1:
                if pos_dic.get(j) is None:
                    pos_dic[j] = 1
                else:
                    pos_dic[j] += 1
            elif y_all[i][j] == 0:
                if neg_dic.get(j) is None:
                    neg_dic[j] = 1
                else:
                    neg_dic[j] += 1

    for key in pos_dic.keys():
        weight_dic[key] = [5000/pos_dic[key], 5000/neg_dic[key]]
    return(weight_dic)

def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        m.weight.data.normal_(0.0, 0.02)
    elif classname.find('BatchNorm') != -1:
        m.weight.data.normal_(1.0, 0.02)
        m.bias.data.fill_(0)
    if classname.find('Conv2d') != -1:
        m.weight.data.fill_(1.0)

def rsquared(x, y):
    """ Return R^2 where x and y are array-like."""
    slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(x, y)
    return r_value**2

def got_all_bondType_tox21(dataset, path='../data/'):

    data = []
    with open('{}{}'.format(path, dataset), 'r') as data_fid:
        reader = csv.reader(data_fid, delimiter='\t', quotechar="'")
        for row in reader:
            data.append(row)

    bondtype_list = []
    for row in data[1:11746]:  # Wierd, the len(data) is longer, but no data was in the rest of part.
        smile = row[0]
        mol = MolFromSmiles(smile)
        bondtype_list = fillBondType(mol, bondtype_list)
    bondtype_list.sort()
    return(bondtype_list)

def got_all_bondType_tox21_dic(dataset, path='../data/'):
    if dataset == 'coley_tox21.tdf':
        delimiter = '\t'
        quotechar = "'"
        smile_idx = 0
        len_data = 11746
    elif dataset == 'tox21.csv':
        delimiter = ','
        quotechar = '"'
        smile_idx = 13
        len_data = 7832
    elif dataset =='HIV.csv':
        delimiter = ','
        quotechar = '"'
        smile_idx = 0
        len_data = 82255

    data = []
    with open('{}{}'.format(path, dataset), 'r') as data_fid:
        reader = csv.reader(data_fid, delimiter=delimiter, quotechar=quotechar)
        for row in reader:
            data.append(row)

    bondtype_dic = {}
    for row in data[1:len_data]:  # Wierd, the len(data) is longer, but no data was in the rest of part.
        if len(row) == 0:
            continue
        smile = row[smile_idx]
        try:
            mol = MolFromSmiles(smile)
            bondtype_dic = fillBondType_dic(mol, bondtype_dic)
        except AttributeError:
            pass
    return(bondtype_dic)

def got_all_atomType_tox21_dic(dataset, path='../data/'):

    data = []
    if dataset == 'coley_tox21.tdf':
        delimiter = '\t'
        quotechar = "'"
        smile_idx = 0
        len_data = 11746
    elif dataset == 'tox21.csv':
        delimiter = ','
        quotechar = '"'
        smile_idx = 13
        len_data = 7832
    elif dataset =='HIV.csv':
        delimiter = ','
        quotechar = '"'
        smile_idx = 0
        len_data = 82255

    with open('{}{}'.format(path, dataset), 'r') as data_fid:
        reader = csv.reader(data_fid, delimiter=delimiter, quotechar=quotechar)
        for row in reader:
            data.append(row)

    atomtype_dic = {}
    for row in data[1:len_data]:  # Wierd, the len(data) is longer, but no data was in the rest of part.
        if len(row) == 0:
            continue
        smile = row[smile_idx]
        try:
            mol = MolFromSmiles(smile)
            atomtype_dic = fillAtomType_dic(mol, atomtype_dic)
        except AttributeError:
            pass
    return(atomtype_dic)

def got_all_Type_solu_dic(dataset, path='../data/'):
    if dataset == 'Lipophilicity.csv':
        delimiter = ','
        quotechar = '"'
        smile_idx = 2
        len_data = 4201
    elif dataset =='HIV.csv':
        delimiter = ','
        quotechar = '"'
        smile_idx = 0
        len_data = 82255
    elif dataset == 'SAMPL.csv':
        delimiter = ','
        quotechar = '"'
        smile_idx = 1
        len_data = 643
    elif dataset == 'tox21.csv':
        delimiter = ','
        quotechar = '"'
        smile_idx = 13
        len_data = 7832

    data = []
    with open('{}{}'.format(path, dataset), 'r') as data_fid:
        reader = csv.reader(data_fid, delimiter=delimiter, quotechar=quotechar)
        for row in reader:
            data.append(row)

    bondtype_dic = {}
    atomtype_dic = {}
    for row in data[1:len_data]:  # Wierd, the len(data) is longer, but no data was in the rest of part.
        if len(row) == 0:
            continue
        smile = row[smile_idx]
        try:
            mol = MolFromSmiles(smile)
            bondtype_dic = fillBondType_dic(mol, bondtype_dic)
            atomtype_dic = fillAtomType_dic(mol, atomtype_dic)
        except AttributeError:
            pass
        else:
            pass
    return(bondtype_dic, atomtype_dic)

def data_padding(x, max_size):
    btf_len = x[0][2].shape[0]
    x_padded = []
    for data in x:  # afm, adj, bft
        filled_adj = np.zeros((max_size, max_size), dtype=np.float32)
        filled_adj[0:data[1].shape[0], 0:data[1].shape[0]] = data[1]
        filled_afm = np.zeros((max_size, 25), dtype=np.float32)
        filled_afm[0:data[0].shape[0], :] = data[0]
        filled_bft = np.zeros((btf_len, max_size, max_size), dtype=np.float32)
        filled_bft[:, 0:data[0].shape[0], 0:data[0].shape[0]] = data[2]

        x_padded.append([filled_adj, filled_afm, filled_bft])
    return(x_padded)

def construct_loader(x, y, target, batch_size, shuffle=True):
    data_set = construct_dataset(x, y, target)
    data_set = MolDataset(data_set)
    loader = torch.utils.data.DataLoader(dataset=data_set,
                                               batch_size=batch_size,
                                               collate_fn=mol_collate_func_class,
                                               shuffle=shuffle)
    return loader

def construct_loader_reg(x, y, target, batch_size, shuffle=True):
    data_set = construct_dataset(x, y, target)
    data_set = MolDataset(data_set)
    loader = torch.utils.data.DataLoader(dataset=data_set,
                                               batch_size=batch_size,
                                               collate_fn=mol_collate_func_reg,
                                               shuffle=shuffle)
    return loader

def earily_stop(val_acc_history, tasks, early_stop_step_single,
                early_stop_step_multi, required_progress):
    """
    Stop the training if there is no non-trivial progress in k steps
    @param val_acc_history: a list contains all the historical validation acc
    @param required_progress: the next acc should be higher than the previous by
        at least required_progress amount to be non-trivial
    @param t: number of training steps
    @return: a boolean indicates if the model should earily stop
    """
    # TODO: add your code here
    if len(tasks) == 1:
        t = early_stop_step_single
    else:
        t = early_stop_step_multi

    if len(val_acc_history)>t:
        if val_acc_history[-1] - val_acc_history[-1-t] < required_progress:
            return True
    return False

'''
# load_chem(data_name='tox21')
dat = torch.load("../data/tox21.pt")
g1_x = dat[0][0][0]
g1_adj = dat[0][0][1]
g1_eadj, g1_ename = node_adj_to_edge_adj(g1_adj)
g1_connection = dat[0][0][2]

print("tmat is: ", get_transition_matrix(g1_adj))
print(connection_type_to_edge_feat(g1_connection, g1_ename))
'''
def prepare_data_dict(dat):
    # dat = [all_x all_y, target, sizes]
    N = len(dat[0])
    RES = {}

    for i in range(N):
        x = dat[0][i][0]
        adj = dat[0][i][1]
        eadj, ename = node_adj_to_edge_adj(adj)
        tmat = get_transition_matrix(adj)
        z_bondtype = connection_type_to_edge_feat(dat[0][i][2], ename)
        z_bondorder = connection_type_to_edge_feat(dat[0][i][3], ename)
        z_arom = connection_type_to_edge_feat(dat[0][i][4], ename)
        z_conj = connection_type_to_edge_feat(dat[0][i][5], ename)
        z_ring = connection_type_to_edge_feat(dat[0][i][6], ename)
        z = np.concatenate([z_bondtype, z_bondorder, z_arom, z_conj, z_ring], axis=1)
        target = dat[1][i]
        size = dat[3][i]
        RES[i] = [adj, eadj, x, z, target, tmat, size]
    return RES

'''
t = time.time()
res = load_chem("tox21")
print(res.keys())
print("time cost is : ", time.time() - t)

'''
def minibatch_chem(inputs, batchsize, train_ratio, val_ratio, test_ratio):
    # inputs is [dict, idx_train, idx_val, idx_test], where the dict = {id: [adj, eadj, x, z, target, tmat, size]}
    # outputs: a list of batches, each batch = [adj, y, x, eadj, tmatrix, z, idx_train, idx_val]
    # return [adj, y, x, eadj, tmatrix, z, idx_train, idx_val]
    
    # we shuffle the idx
    #ids_train_val = np.concatenate(inputs[1], inputs[2])
    #np.random.shuffle(ids_train_val)
    #inputs[1] = all_ids[0: len(inputs[1])]
    #inputs[2] = all_ids[0: len(inputs[2])]
    
    assert inputs is not None
    # numSamples = len(inputs[0].keys())
    numSamples = len(inputs[1]) + len(inputs[2]) + len(inputs[3])
    # print(numSamples)
    n_batch = numSamples // batchsize
    
    # n_train_batch = int(0.6 * batchsize)
    n_val_batch = int(val_ratio * batchsize) 
    n_test_batch = int(test_ratio * batchsize)
    n_train_batch = batchsize - n_val_batch - n_test_batch
    # n_test_batch = batchsize - n_train_batch - n_val_batch
    data_list = []

    # shuffle train, val and test
    # np.random.seed(1234)
    np.random.shuffle(inputs[1])
    np.random.shuffle(inputs[2])
    np.random.shuffle(inputs[3])
    
    for i in range(n_batch - 2):
        # t = time.time()
        # if i % 5 == 0:
            # print("Loaded batches", i)
        idx_train_batch = inputs[1][range(i * n_train_batch, (i+1) * n_train_batch)]
        # print("Pring the idx batch and our selected ranges")
        # print("idx_val is :", len(inputs[2]))
        # print("the range is :", list(range(i * n_val_batch, (i+1) * n_val_batch)))
        
        idx_val_batch = inputs[2][range(i * n_val_batch, (i+1) * n_val_batch)]
        idx_test_batch = inputs[3][range(i * n_test_batch, (i+1) * n_test_batch)]

        idx_batch = np.concatenate([idx_train_batch, idx_val_batch, idx_test_batch])
        data_batch = operator.itemgetter(*idx_batch)(inputs[0])         

        adjs, eadjs, xs, zs, targets, tmats, sizes = list(zip(*data_batch))
        adj = block_diag(*adjs)
        eadj = block_diag(*eadjs)
        tmat = block_diag(*tmats)
        x = np.concatenate(xs, axis=0)
        z = np.concatenate(zs, axis=0)
        y = np.array(targets)
        node_freq = list(sizes)     
        ind = list(range(len(node_freq)))
        repeated_ind = np.repeat(ind, node_freq)
        pooling = encode_onehot(repeated_ind).T 
        
        ''' 
        # create batch_graph_T, batch_size * num_of_graphs
        row, col = list(range(batchsize)), idx_batch
        values = np.ones(batchsize)
        batch_graph_T = sp.csr_matrix((values, (row, col)), shape=(batchsize, numSamples)) 
        batch_graph_T = dense_tensor_to_sparse(torch.FloatTensor(batch_graph_T.toarray()))
        
        # create batch_node_T
        col = list(range(adj.shape[0]))
        graph_size_list_cumsum = np.array(graph_size_list).cumsum()
        row = []
        for i in range(batchsize):
            if idx_batch[i] == 0:
                row.append(list(range(graph_size_list_cumsum[0])))
            else:
                row.append(list(range(graph_size_list_cumsum[idx_batch[i]-1], graph_size_list_cumsum[idx_batch[i]])))
        row = np.concatenate(row).tolist()
        values = np.ones(adj.shape[0])
        batch_node_T = sp.csr_matrix((values,(row, col)), shape=(np.sum(graph_size_list), adj.shape[0]))
        batch_node_T = dense_tensor_to_sparse(torch.FloatTensor(batch_node_T.toarray()))
        '''

        data_list.append([dense_tensor_to_sparse(torch.FloatTensor(normalize(adj))),
               torch.FloatTensor(y),
               torch.FloatTensor(normalize(x)),
               dense_tensor_to_sparse(torch.FloatTensor(normalize(eadj))),
               dense_tensor_to_sparse(torch.FloatTensor(tmat)),
               torch.FloatTensor(normalize(z)),
               torch.tensor(range(n_train_batch)),
               torch.tensor(range(n_train_batch, n_train_batch + n_val_batch)),
               torch.FloatTensor(pooling),
               torch.FloatTensor(node_freq),
               ])
    # get the reminder
    n_train_reminder = len(inputs[1]) - n_train_batch * (n_batch - 2)
    n_val_reminder = len(inputs[2]) - n_val_batch * (n_batch - 2) 
    idx_train_reminder = inputs[1][range(n_train_batch * (n_batch - 2), len(inputs[1]) - 1)]
    idx_val_reminder = inputs[2][range(n_val_batch * (n_batch - 2), len(inputs[2]) - 1)] 
    idx_test_reminder = inputs[3][range(n_test_batch * (n_batch - 2), len(inputs[3]) - 1)]
    idx_batch = np.concatenate([idx_train_reminder, idx_val_reminder, idx_test_reminder])
    data_batch = operator.itemgetter(*idx_batch)(inputs[0])         
    # print("Pring the idx batch and our selected ranges")
    # print("idx_val is :", len(inputs[2]))
    # print("the range is :", list(range(n_val_batch * (n_batch - 1), len(inputs[2]) - 1)))
    
    adjs, eadjs, xs, zs, targets, tmats, sizes = list(zip(*data_batch))
    adj = block_diag(*adjs)
    eadj = block_diag(*eadjs)
    tmat = block_diag(*tmats)
    x = np.concatenate(xs, axis=0)
    z = np.concatenate(zs, axis=0)
    y = np.array(targets)
    node_freq = list(sizes)     
    ind = list(range(len(node_freq)))
    repeated_ind = np.repeat(ind, node_freq)
    pooling = encode_onehot(repeated_ind).T 
    ''' 
    # create batch_graph_T, batch_size * num_of_graphs
    row, col = list(range(len(idx_batch))), idx_batch
    values = np.ones(len(idx_batch))
    batch_graph_T = sp.csr_matrix((values, (row, col)), shape=(len(idx_batch), numSamples)) 
    batch_graph_T = dense_tensor_to_sparse(torch.FloatTensor(batch_graph_T.toarray()))
    
    # create batch_node_T
    col = list(range(adj.shape[0]))
    graph_size_list_cumsum = np.array(graph_size_list).cumsum()
    row = []
    for i in range(len(idx_batch)):
        if idx_batch[i] == 0:
            row.append(list(range(graph_size_list_cumsum[0])))
        else:
            row.append(list(range(graph_size_list_cumsum[idx_batch[i]-1], graph_size_list_cumsum[idx_batch[i]])))
    row = np.concatenate(row).tolist()
    values = np.ones(adj.shape[0])
    batch_node_T = sp.csr_matrix((values,(row, col)), shape=(np.sum(graph_size_list), adj.shape[0]))
    batch_node_T = dense_tensor_to_sparse(torch.FloatTensor(batch_node_T.toarray()))
    '''    
    data_list.append([dense_tensor_to_sparse(torch.FloatTensor(normalize(adj))),
           torch.FloatTensor(y),
           torch.FloatTensor(normalize(x)),
           dense_tensor_to_sparse(torch.FloatTensor(normalize(eadj))),
           dense_tensor_to_sparse(torch.FloatTensor(tmat)),
           torch.FloatTensor(normalize(z)),
           torch.tensor(range(n_train_reminder)),
           torch.tensor(range(n_train_reminder, n_train_reminder + n_val_reminder)),
           torch.FloatTensor(pooling),
           torch.FloatTensor(node_freq),
           ])
        # print("cost of generating each batch: ", time.time() -t )
    return data_list
        # print(adj.shape, eadj.shape, tmat.shape, x.shape, z.shape, y.shape, len(node_freq))

def minibatch_chem_test(inputs, batchsize):
    # inputs is [dict, idx_train, idx_val, idx_test], where the dict = {id: [adj, eadj, x, z, target, tmat, size]}
    # outputs: a list of batches, each batch = [adj, y, x, eadj, tmatrix, z]
    # return [adj, y, x, eadj, tmatrix, z]
    assert inputs is not None
    numSamples = len(inputs[1]) + len(inputs[2]) + len(inputs[3])
    n_batch = len(inputs[3]) // batchsize
    data_list = []

    for i in range(n_batch - 2):
        # t = time.time()
        idx_batch = inputs[3][range(i * batchsize, (i+1) * batchsize)]
        data_batch = operator.itemgetter(*idx_batch)(inputs[0])         
        adjs, eadjs, xs, zs, targets, tmats, sizes = list(zip(*data_batch))
        adj = block_diag(*adjs)
        eadj = block_diag(*eadjs)
        tmat = block_diag(*tmats)
        x = np.concatenate(xs, axis=0)
        z = np.concatenate(zs, axis=0)
        y = np.array(targets)
        # print("the targets is : ", targets, len(targets))
        # print(" the y is : ", y, len(y))
        node_freq = list(sizes)     
        ind = list(range(len(node_freq)))
        repeated_ind = np.repeat(ind, node_freq)
        pooling = encode_onehot(repeated_ind).T 
        ''' 
        # create batch_graph_T, batch_size * num_of_graphs
        row, col = list(range(batchsize)), idx_batch
        values = np.ones(batchsize)
        batch_graph_T = sp.csr_matrix((values, (row, col)), shape=(batchsize, numSamples)) 
        batch_graph_T = dense_tensor_to_sparse(torch.FloatTensor(batch_graph_T.toarray()))
        
        # create batch_node_T
        col = list(range(adj.shape[0]))
        graph_size_list_cumsum = np.array(graph_size_list).cumsum()
        row = []
        for i in range(batchsize):
            if idx_batch[i] == 0:
                row.append(list(range(graph_size_list_cumsum[0])))
            else:
                row.append(list(range(graph_size_list_cumsum[idx_batch[i]-1], graph_size_list_cumsum[idx_batch[i]])))
        row = np.concatenate(row).tolist()
        values = np.ones(adj.shape[0])
        batch_node_T = sp.csr_matrix((values,(row, col)), shape=(np.sum(graph_size_list), adj.shape[0]))
        batch_node_T = dense_tensor_to_sparse(torch.FloatTensor(batch_node_T.toarray()))
        '''
        data_list.append([dense_tensor_to_sparse(torch.FloatTensor(normalize(adj))),
               torch.FloatTensor(y),
               torch.FloatTensor(normalize(x)),
               dense_tensor_to_sparse(torch.FloatTensor(normalize(eadj))),
               dense_tensor_to_sparse(torch.FloatTensor(tmat)),
               torch.FloatTensor(normalize(z)),
               torch.FloatTensor(pooling),
               torch.FloatTensor(node_freq),
               ])
        # print("cost of generating each batch: ", time.time() -t )
    reminder_n = len(inputs[3]) - (n_batch -2)* batchsize
    # print(reminder_n)
    idx_batch = inputs[3][(n_batch-2)*batchsize:]
    data_batch = operator.itemgetter(*idx_batch)(inputs[0])         

    adjs, eadjs, xs, zs, targets, tmats, sizes = list(zip(*data_batch))
    adj = block_diag(*adjs)
    eadj = block_diag(*eadjs)
    tmat = block_diag(*tmats)
    x = np.concatenate(xs, axis=0)
    z = np.concatenate(zs, axis=0)
    y = np.array(targets)
    node_freq = list(sizes)
    ind = list(range(len(node_freq)))
    repeated_ind = np.repeat(ind, node_freq)
    pooling = encode_onehot(repeated_ind).T 
    ''' 
    # create batch_graph_T, batch_size * num_of_graphs
    row, col = list(range(len(idx_batch))), idx_batch
    values = np.ones(len(idx_batch))
    batch_graph_T = sp.csr_matrix((values, (row, col)), shape=(len(idx_batch), numSamples)) 
    batch_graph_T = dense_tensor_to_sparse(torch.FloatTensor(batch_graph_T.toarray()))
    
    # create batch_node_T
    col = list(range(adj.shape[0]))
    graph_size_list_cumsum = np.array(graph_size_list).cumsum()
    row = []
    for i in range(len(idx_batch)):
        if idx_batch[i] == 0:
            row.append(list(range(graph_size_list_cumsum[0])))
        else:
            row.append(list(range(graph_size_list_cumsum[idx_batch[i]-1], graph_size_list_cumsum[idx_batch[i]])))
    row = np.concatenate(row).tolist()
    values = np.ones(adj.shape[0])
    batch_node_T = sp.csr_matrix((values,(row, col)), shape=(np.sum(graph_size_list), adj.shape[0]))
    batch_node_T = dense_tensor_to_sparse(torch.FloatTensor(batch_node_T.toarray()))
    '''
    data_list.append([dense_tensor_to_sparse(torch.FloatTensor(normalize(adj))),
               torch.FloatTensor(y),
               torch.FloatTensor(normalize(x)),
               dense_tensor_to_sparse(torch.FloatTensor(normalize(eadj))),
               dense_tensor_to_sparse(torch.FloatTensor(tmat)),
               torch.FloatTensor(normalize(z)),
               torch.FloatTensor(pooling),
               torch.FloatTensor(node_freq),
               ])
    return data_list

def minibatch_chem2(inputs, batchsize):
    # inputs is [dict, idx_train, idx_val, idx_test], where the dict = {id: [adj, eadj, x, z, target, tmat, size]}
    # outputs: a list of batches, each batch = [adj, y, x, eadj, tmatrix, z, idx_train, idx_val]
    # return [adj, y, x, eadj, tmatrix, z, idx_train, idx_val]
    
    # we shuffle the idx
    #ids_train_val = np.concatenate(inputs[1], inputs[2])
    #np.random.shuffle(ids_train_val)
    #inputs[1] = all_ids[0: len(inputs[1])]
    #inputs[2] = all_ids[0: len(inputs[2])]
    
    assert inputs is not None
    # numSamples = len(inputs[0].keys())
    # numSamples = len(inputs[1]) + len(inputs[2]) + len(inputs[3])
    # print(numSamples)
    n_batch = len(inputs[1]) // batchsize # purely depends on training
    
    n_train_batch = batchsize 
    n_val_batch = batchsize // 2
    # n_test_batch = int(test_ratio * batchsize)
    # n_train_batch = batchsize - n_val_batch - n_test_batch
    # n_test_batch = batchsize - n_train_batch - n_val_batch
    data_list = []

    # shuffle train, val and test
    # np.random.seed(1234)
    np.random.shuffle(inputs[1])
    np.random.shuffle(inputs[2])
    np.random.shuffle(inputs[3])
    
    for i in range(n_batch - 2):
        # t = time.time()
        # if i % 5 == 0:
            # print("Loaded batches", i)
        idx_train_batch = inputs[1][range(i * n_train_batch, (i+1) * n_train_batch)]

        # we randomly match half batchsize number of val as val in each batch
        idx_val_batch = np.random.choice(inputs[2], n_val_batch, replace=False)
        # idx_val_batch = inputs[2][range(i * n_val_batch, (i+1) * n_val_batch)]

        idx_batch = np.concatenate([idx_train_batch, idx_val_batch])
        data_batch = operator.itemgetter(*idx_batch)(inputs[0])         

        adjs, eadjs, xs, zs, targets, tmats, sizes = list(zip(*data_batch))
        adj = block_diag(*adjs)
        eadj = block_diag(*eadjs)
        tmat = block_diag(*tmats)
        x = np.concatenate(xs, axis=0)
        z = np.concatenate(zs, axis=0)
        y = np.array(targets)
        node_freq = list(sizes)     
        ind = list(range(len(node_freq)))
        repeated_ind = np.repeat(ind, node_freq)
        pooling = encode_onehot(repeated_ind).T 

        data_list.append([dense_tensor_to_sparse(torch.FloatTensor(normalize(adj))),
               torch.FloatTensor(y),
               torch.FloatTensor(normalize(x)),
               dense_tensor_to_sparse(torch.FloatTensor(normalize(eadj))),
               dense_tensor_to_sparse(torch.FloatTensor(tmat)),
               torch.FloatTensor(normalize(z)),
               torch.tensor(range(n_train_batch)),
               torch.tensor(range(n_train_batch, n_train_batch + n_val_batch)),
               torch.FloatTensor(pooling),
               torch.FloatTensor(node_freq),
               ])
    # get the reminder
    n_train_reminder = len(inputs[1]) - n_train_batch * (n_batch - 2)
    # n_val_reminder = len(inputs[2]) - n_val_batch * (n_batch - 2) 
    idx_train_reminder = inputs[1][range(n_train_batch * (n_batch - 2), len(inputs[1]) - 1)]
    idx_val_reminder = np.random.choice(inputs[2], len(idx_train_reminder) // 2, replace=False)
    # idx_val_reminder = inputs[2][range(n_val_batch * (n_batch - 2), len(inputs[2]) - 1)] 
    # idx_test_reminder = inputs[3][range(n_test_batch * (n_batch - 2), len(inputs[3]) - 1)]
    idx_batch = np.concatenate([idx_train_reminder, idx_val_reminder])
    data_batch = operator.itemgetter(*idx_batch)(inputs[0])         
    # print("Pring the idx batch and our selected ranges")
    # print("idx_val is :", len(inputs[2]))
    # print("the range is :", list(range(n_val_batch * (n_batch - 1), len(inputs[2]) - 1)))
    
    adjs, eadjs, xs, zs, targets, tmats, sizes = list(zip(*data_batch))
    adj = block_diag(*adjs)
    eadj = block_diag(*eadjs)
    tmat = block_diag(*tmats)
    x = np.concatenate(xs, axis=0)
    z = np.concatenate(zs, axis=0)
    y = np.array(targets)
    node_freq = list(sizes)     
    ind = list(range(len(node_freq)))
    repeated_ind = np.repeat(ind, node_freq)
    pooling = encode_onehot(repeated_ind).T 
    ''' 
    # create batch_graph_T, batch_size * num_of_graphs
    row, col = list(range(len(idx_batch))), idx_batch
    values = np.ones(len(idx_batch))
    batch_graph_T = sp.csr_matrix((values, (row, col)), shape=(len(idx_batch), numSamples)) 
    batch_graph_T = dense_tensor_to_sparse(torch.FloatTensor(batch_graph_T.toarray()))
    
    # create batch_node_T
    col = list(range(adj.shape[0]))
    graph_size_list_cumsum = np.array(graph_size_list).cumsum()
    row = []
    for i in range(len(idx_batch)):
        if idx_batch[i] == 0:
            row.append(list(range(graph_size_list_cumsum[0])))
        else:
            row.append(list(range(graph_size_list_cumsum[idx_batch[i]-1], graph_size_list_cumsum[idx_batch[i]])))
    row = np.concatenate(row).tolist()
    values = np.ones(adj.shape[0])
    batch_node_T = sp.csr_matrix((values,(row, col)), shape=(np.sum(graph_size_list), adj.shape[0]))
    batch_node_T = dense_tensor_to_sparse(torch.FloatTensor(batch_node_T.toarray()))
    '''    
    data_list.append([dense_tensor_to_sparse(torch.FloatTensor(normalize(adj))),
           torch.FloatTensor(y),
           torch.FloatTensor(normalize(x)),
           dense_tensor_to_sparse(torch.FloatTensor(normalize(eadj))),
           dense_tensor_to_sparse(torch.FloatTensor(tmat)),
           torch.FloatTensor(normalize(z)),
           torch.tensor(range(n_train_reminder)),
           torch.tensor(range(n_train_reminder, n_train_reminder + n_train_reminder//2)),
           torch.FloatTensor(pooling),
           torch.FloatTensor(node_freq),
           ])
        # print("cost of generating each batch: ", time.time() -t )
    return data_list
        # print(adj.shape, eadj.shape, tmat.shape, x.shape, z.shape, y.shape, len(node_freq))

def minibatch_chem_test2(inputs, batchsize):
    # inputs is [dict, idx_train, idx_val, idx_test], where the dict = {id: [adj, eadj, x, z, target, tmat, size]}
    # outputs: a list of batches, each batch = [adj, y, x, eadj, tmatrix, z]
    # return [adj, y, x, eadj, tmatrix, z]
    assert inputs is not None
    numSamples = len(inputs[1]) + len(inputs[2]) + len(inputs[3])
    n_batch = len(inputs[3]) // batchsize
    data_list = []

    for i in range(n_batch - 2):
        # t = time.time()
        idx_batch = inputs[3][range(i * batchsize, (i+1) * batchsize)]
        data_batch = operator.itemgetter(*idx_batch)(inputs[0])         
        adjs, eadjs, xs, zs, targets, tmats, sizes = list(zip(*data_batch))
        adj = block_diag(*adjs)
        eadj = block_diag(*eadjs)
        tmat = block_diag(*tmats)
        x = np.concatenate(xs, axis=0)
        z = np.concatenate(zs, axis=0)
        y = np.array(targets)
        # print("the targets is : ", targets, len(targets))
        # print(" the y is : ", y, len(y))
        node_freq = list(sizes)     
        ind = list(range(len(node_freq)))
        repeated_ind = np.repeat(ind, node_freq)
        pooling = encode_onehot(repeated_ind).T 
        ''' 
        # create batch_graph_T, batch_size * num_of_graphs
        row, col = list(range(batchsize)), idx_batch
        values = np.ones(batchsize)
        batch_graph_T = sp.csr_matrix((values, (row, col)), shape=(batchsize, numSamples)) 
        batch_graph_T = dense_tensor_to_sparse(torch.FloatTensor(batch_graph_T.toarray()))
        
        # create batch_node_T
        col = list(range(adj.shape[0]))
        graph_size_list_cumsum = np.array(graph_size_list).cumsum()
        row = []
        for i in range(batchsize):
            if idx_batch[i] == 0:
                row.append(list(range(graph_size_list_cumsum[0])))
            else:
                row.append(list(range(graph_size_list_cumsum[idx_batch[i]-1], graph_size_list_cumsum[idx_batch[i]])))
        row = np.concatenate(row).tolist()
        values = np.ones(adj.shape[0])
        batch_node_T = sp.csr_matrix((values,(row, col)), shape=(np.sum(graph_size_list), adj.shape[0]))
        batch_node_T = dense_tensor_to_sparse(torch.FloatTensor(batch_node_T.toarray()))
        '''
        data_list.append([dense_tensor_to_sparse(torch.FloatTensor(normalize(adj))),
               torch.FloatTensor(y),
               torch.FloatTensor(normalize(x)),
               dense_tensor_to_sparse(torch.FloatTensor(normalize(eadj))),
               dense_tensor_to_sparse(torch.FloatTensor(tmat)),
               torch.FloatTensor(normalize(z)),
               torch.FloatTensor(pooling),
               torch.FloatTensor(node_freq),
               ])
        # print("cost of generating each batch: ", time.time() -t )
    reminder_n = len(inputs[3]) - (n_batch -2)* batchsize
    # print(reminder_n)
    idx_batch = inputs[3][(n_batch-2)*batchsize:]
    data_batch = operator.itemgetter(*idx_batch)(inputs[0])         

    adjs, eadjs, xs, zs, targets, tmats, sizes = list(zip(*data_batch))
    adj = block_diag(*adjs)
    eadj = block_diag(*eadjs)
    tmat = block_diag(*tmats)
    x = np.concatenate(xs, axis=0)
    z = np.concatenate(zs, axis=0)
    y = np.array(targets)
    node_freq = list(sizes)
    ind = list(range(len(node_freq)))
    repeated_ind = np.repeat(ind, node_freq)
    pooling = encode_onehot(repeated_ind).T 
    ''' 
    # create batch_graph_T, batch_size * num_of_graphs
    row, col = list(range(len(idx_batch))), idx_batch
    values = np.ones(len(idx_batch))
    batch_graph_T = sp.csr_matrix((values, (row, col)), shape=(len(idx_batch), numSamples)) 
    batch_graph_T = dense_tensor_to_sparse(torch.FloatTensor(batch_graph_T.toarray()))
    
    # create batch_node_T
    col = list(range(adj.shape[0]))
    graph_size_list_cumsum = np.array(graph_size_list).cumsum()
    row = []
    for i in range(len(idx_batch)):
        if idx_batch[i] == 0:
            row.append(list(range(graph_size_list_cumsum[0])))
        else:
            row.append(list(range(graph_size_list_cumsum[idx_batch[i]-1], graph_size_list_cumsum[idx_batch[i]])))
    row = np.concatenate(row).tolist()
    values = np.ones(adj.shape[0])
    batch_node_T = sp.csr_matrix((values,(row, col)), shape=(np.sum(graph_size_list), adj.shape[0]))
    batch_node_T = dense_tensor_to_sparse(torch.FloatTensor(batch_node_T.toarray()))
    '''
    data_list.append([dense_tensor_to_sparse(torch.FloatTensor(normalize(adj))),
               torch.FloatTensor(y),
               torch.FloatTensor(normalize(x)),
               dense_tensor_to_sparse(torch.FloatTensor(normalize(eadj))),
               dense_tensor_to_sparse(torch.FloatTensor(tmat)),
               torch.FloatTensor(normalize(z)),
               torch.FloatTensor(pooling),
               torch.FloatTensor(node_freq),
               ])
    return data_list

def minibatchLoader(inputs, batchsize):
    # inputs is [dict, ids], where the dict = {id: [adj, eadj, x, z, target, tmat, size]}
    # outputs: a list of batches, each batch = [adj, y, x, eadj, tmatrix, z]
    # return [adj, y, x, eadj, tmatrix, z]
    assert inputs is not None
    # numSamples = len(inputs[1]) + len(inputs[2]) + len(inputs[3])
    n_batch = len(inputs[1]) // batchsize
    data_list = []

    for i in range(n_batch - 2):
        # t = time.time()
        idx_batch = inputs[1][range(i * batchsize, (i+1) * batchsize)]
        data_batch = operator.itemgetter(*idx_batch)(inputs[0])         
        adjs, eadjs, xs, zs, targets, tmats, sizes = list(zip(*data_batch))
        adj = block_diag(*adjs)
        eadj = block_diag(*eadjs)
        tmat = block_diag(*tmats)
        x = np.concatenate(xs, axis=0)
        z = np.concatenate(zs, axis=0)
        y = np.array(targets)
        # print("the targets is : ", targets, len(targets))
        # print(" the y is : ", y, len(y))
        node_freq = list(sizes)     
        ind = list(range(len(node_freq)))
        repeated_ind = np.repeat(ind, node_freq)
        pooling = encode_onehot(repeated_ind).T 
        data_list.append([dense_tensor_to_sparse(torch.FloatTensor(normalize(adj))),
               torch.FloatTensor(y),
               torch.FloatTensor(normalize(x)),
               dense_tensor_to_sparse(torch.FloatTensor(normalize(eadj))),
               dense_tensor_to_sparse(torch.FloatTensor(tmat)),
               torch.FloatTensor(normalize(z)),
               torch.FloatTensor(pooling),
               torch.FloatTensor(node_freq),
               ])
        # print("cost of generating each batch: ", time.time() -t )
    reminder_n = len(inputs[1]) - (n_batch -2)* batchsize
    # print(reminder_n)
    idx_batch = inputs[1][(n_batch-2)*batchsize:]
    data_batch = operator.itemgetter(*idx_batch)(inputs[0])         

    adjs, eadjs, xs, zs, targets, tmats, sizes = list(zip(*data_batch))
    adj = block_diag(*adjs)
    eadj = block_diag(*eadjs)
    tmat = block_diag(*tmats)
    x = np.concatenate(xs, axis=0)
    z = np.concatenate(zs, axis=0)
    y = np.array(targets)
    node_freq = list(sizes)
    ind = list(range(len(node_freq)))
    repeated_ind = np.repeat(ind, node_freq)
    pooling = encode_onehot(repeated_ind).T 
    data_list.append([dense_tensor_to_sparse(torch.FloatTensor(normalize(adj))),
               torch.FloatTensor(y),
               torch.FloatTensor(normalize(x)),
               dense_tensor_to_sparse(torch.FloatTensor(normalize(eadj))),
               dense_tensor_to_sparse(torch.FloatTensor(tmat)),
               torch.FloatTensor(normalize(z)),
               torch.FloatTensor(pooling),
               torch.FloatTensor(node_freq),
               ])
    return data_list

'''
import collections
# from torch.autograd import Variable
t = time.time()
dat = load_chem("freesolv")
#print(dat[0][0])
#print(dat[1])
#print(dat[2])
#print(dat[3])
print(minibatch_chem(dat, 128))

# from operator import itemgetter
# a = load_chem('tox21')
#ys = []
#for i in range(40000):
#    ys.append(dat[0][i][4])
# print(ys)
# print(collections.Counter(np.concatenate(ys)))
print(time.time() - t)
# print(set_weight(ys))
# print(dat[0][0][4])
'''




# b = minibatch_chem(dat, 128)
