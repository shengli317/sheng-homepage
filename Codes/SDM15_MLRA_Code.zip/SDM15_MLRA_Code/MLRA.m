function [AUC] = MLRA(X1,X2,label,outLabel,para)
% The code of multi-view low-rank analysis (MLRA).
%
% Sheng Li, Ming Shao, Yun Fu: Multi-View Low-Rank Analysis for Outlier Detection. SDM 2015: 748-756
%
% Input:
%         X1 -- D*N data matrix of view 1, where D is the dimension and N is the number
%              of samples.
%         X2 -- D*N data matrix of view 2.
%      label -- class label of samples
%       para -- parameters
% para.alpha -- trade-off parameter
% para.beta  -- trade-off parameter
% para.lambda-- trade-off parameter
% 
% Output:
%        AUC -- the area under ROC curve
%
% Sheng Li (shengli@ece.neu.edu)
% June 29, 2015

alpha = para.alpha;
beta = para.beta;
lambda = para.lambda;

n_c = zeros(1,length(unique(label)));
for i = 1:length(unique(label))
    indi = find(label==i);
    n_c(i) = length(indi);
end

Ublk = ones(n_c(1));
for i = 2:length(n_c)
    Ublk = blkdiag(Ublk, ones(n_c(i)));
end

for i = 1:size(X1,2)
    if norm(X1(:,i)) >= 1e-8
        X1(:,i) = X1(:,i)./norm(X1(:,i));
    end
    if norm(X2(:,i)) >= 1e-8
        X2(:,i) = X2(:,i)./norm(X2(:,i));
    end
end

%%--Preprocessing--%%
Q1 = orth(X1');
Q2 = orth(X2');
dq = min(size(Q1,2),size(Q2,2));
B1 = X1*Q1(:,1:dq);
A1 = B1;
B2 = X2*Q2(:,1:dq);
A2 = B2;

%%--Initialization--%%
tol = 1e-6;
maxIter = 1e6;
[d1, n] = size(X1);
[d2, ~] = size(X2);
m1 = size(A1,2);
m2 = size(A2,2);
rho = 1.1;
max_mu = 1e10;
mu = 1e-3;
atx1 = A1'*X1;
atx2 = A2'*X2;
inv_a1 = inv(A1'*A1+2*eye(m1));
inv_a2 = inv(A2'*A2+2*eye(m2));

Z1 = zeros(m1,n);
Z2 = zeros(m2,n);
E1 = sparse(d1,n);
E2 = sparse(d2,n);
S = zeros(m1,n);

W1 = zeros(d1,n);
W2 = zeros(d2,n);
P1 = zeros(m1,n);
P2 = zeros(m2,n);
Q = zeros(m1,n);

%% Start main loop
iter = 0;
while iter<maxIter
    iter = iter + 1;
    
    %update J1,  J2
    temp = Z1 + P1/mu;
    [U,sigma,V] = svd(temp,'econ');
    sigma = diag(sigma);
    svp = length(find(sigma>1/mu));
    if svp>=1
        sigma = sigma(1:svp)-1/mu;
    else
        svp = 1;
        sigma = 0;
    end
    J1 = U(:,1:svp)*diag(sigma)*V(:,1:svp)';
    
    temp = Z2 + P2/mu;
    [U,sigma,V] = svd(temp,'econ');
    sigma = diag(sigma);
    svp = length(find(sigma>1/mu));
    if svp>=1
        sigma = sigma(1:svp)-1/mu;
    else
        svp = 1;
        sigma = 0;
    end
    J2 = U(:,1:svp)*diag(sigma)*V(:,1:svp)';
    
    %udpate Z1, Z2 
    Z1 = inv_a1*(atx1-A1'*E1+J1+S+Z2+(A1'*W1-P1+Q)/mu);
    Z2 = inv_a2*(atx2-A2'*E2+J2-S+Z1+(A2'*W2-P2-Q)/mu);
    
    %update S
    smaz1 = Z1 - Z2;
    temp = smaz1 - Q/mu;
    S = solve_l1l2(temp,beta/mu);
    
    %update E1, E2
    xmaz1 = X1-A1*Z1;
    temp = xmaz1+W1/mu;
    E1 = solve_l1l2(temp,alpha/mu);
    
    xmaz2 = X2-A2*Z2;
    temp = xmaz2+W2/mu;
    E2 = solve_l1l2(temp,alpha/mu);
    
    leq1 = xmaz1-E1;
    leq2 = xmaz2-E2;
    leq3 = Z1-J1;
    leq4 = Z2-J2;
    leq5 = S - smaz1;
    maxall = [max(max(abs(leq1))),max(max(abs(leq2))),max(max(abs(leq3))),max(max(abs(leq4))),max(max(abs(leq5)))]; 
    stopC = max(maxall);
    if stopC<tol
        Z1 = Q1(:,1:dq) * Z1;
        Z2 = Q2(:,1:dq) * Z2;
        break;
    else
        W1 = W1 + mu*leq1;
        W2 = W2 + mu*leq2;
        P1 = P1 + mu*leq3;
        P2 = P2 + mu*leq4;
        Q = Q + mu*leq5;
        mu = min(max_mu,mu*rho);
    end
end

Z11 = Ublk.*Z1;
Z22 = Ublk.*Z2;

s1 = sum(Z11.*Z22);
s2 = sum(E1.*E2);
if norm(s2) == 0
    consistency = abs(s1./norm(s1));
else
    consistency = abs(s1./norm(s1)) - lambda*abs(s2./norm(s2));
end
[~, ~, ~, AUC] = perfcurve(outLabel, consistency, 0);

end

function [E] = solve_l1l2(W,lambda)
n = size(W,2);
E = W;
for i=1:n
    E(:,i) = solve_l2(W(:,i),lambda);
end
end

function [x] = solve_l2(w,lambda)
% min lambda |x|_2 + |x-w|_2^2
nw = norm(w);
if nw>lambda
    x = (nw-lambda)*w/nw;
else
    x = zeros(length(w),1);
end
end
