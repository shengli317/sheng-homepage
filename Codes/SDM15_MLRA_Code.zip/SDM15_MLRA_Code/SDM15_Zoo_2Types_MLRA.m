%%--Demo code of SDM 15 Multi-view Outlier Detection Paper--%%
%%--Sheng Li, Ming Shao, Yun Fu: Multi-View Low-Rank Analysis for Outlier
%%Detection. SDM 2015: 748-756--%%
%%--Sheng Li, shengli@ece.neu.edu--%%
%%--June 29, 2015--%%

clear all;
close all;

load Zoo_2Types_demo;

X1 = view1;
X2 = view2;
classLabel = label;
outLabel = out_label;

para.lambda = 0.5;
para.alpha = 0.4;
para.beta = 0.4;
[AUC_val] = MLRA(X1, X2, classLabel, outLabel, para);

fprintf('The AUC is: %f.\n', AUC_val);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%