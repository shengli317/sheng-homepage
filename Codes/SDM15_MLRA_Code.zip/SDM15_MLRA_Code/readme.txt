This folder contains the source codes of synthetic experiments in our SDM 2015 paper.

The main function is MLRA.m. The demo script on Zoo dataset is SDM15_Zoo_2Types_MLRA.m. Please refer to the source codes for detailed explanations.

Please kindly cite the following paper.


Sheng Li, Ming Shao, Yun Fu: Multi-View Low-Rank Analysis for Outlier Detection. SDM 2015: 748-756


@inproceedings{li2015multi,
  title={Multi-view low-rank analysis for outlier detection},
  author={Li, Sheng and Shao, Ming and Fu, Yun},
  booktitle={SIAM International Conference on Data Mining (SDM)},
  pages={748--756},
  year={2015},
  organization={SIAM}
}

The package is for academic use only. For any problem concerning the code, please feel free to contact Sheng Li (shengli@ece.neu.edu).